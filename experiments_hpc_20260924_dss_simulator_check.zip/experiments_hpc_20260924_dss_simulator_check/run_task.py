#!/usr/bin/env python3
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import fcntl
import os
from pathlib import Path
import resource
import time
import traceback
import numpy as np
import torch
import experiment_config as cfg
from io_common import HERE, canonical_hash, code_hash, ensure_design, read_json, result_path, write_json
from paths import dependencies
from simulator import dataset_path, dataset_spec, load_dataset


def check_required(row):
    needed=['tpr','fpr','accuracy','auroc','mse','r2','dparam','d_edge','d_path','time_min']
    for key in needed:
        if row.get(key) is None or not np.isfinite(float(row[key])):
            raise FloatingPointError(f'Required metric {key} is missing/non-finite')
    for key in ('tpr','fpr','accuracy','auroc','dparam','d_edge','d_path'):
        if not -1e-9 <= float(row[key]) <= 1+1e-9: raise ValueError(f'{key} outside [0,1]')
    if row['mse'] < 0 or row['time_min'] < 0 or row['r2'] > 1+1e-9: raise ValueError('Invalid metric')


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--condition',required=True,choices=cfg.CONDITIONS)
    p.add_argument('--variant',required=True,choices=cfg.VARIANTS)
    p.add_argument('--index',type=int,required=True)
    p.add_argument('--root',type=Path,default=HERE/'results')
    p.add_argument('--smoke',action='store_true')
    p.add_argument('--retry-failed',action='store_true')
    a=p.parse_args(); cfg.validate()
    if not 0 <= a.index < len(cfg.SEEDS): raise ValueError(f'Index must be 0..{len(cfg.SEEDS)-1}')
    root=a.root.resolve(); signature=ensure_design(root); chash=code_hash()
    manifest_path=root/'execution.json'
    if manifest_path.exists():
        manifest=read_json(manifest_path)
        if manifest['code_hash'] != chash or manifest['smoke'] != a.smoke:
            raise RuntimeError('Execution configuration mismatch; use a new root')
    seed=cfg.SEEDS[a.index]
    # Reuse result_path's scenario/method slots as condition/variant.
    dest=result_path(root,a.condition,a.variant,seed)
    c=cfg.training_config(a.variant,a.smoke); c['sigma2']=cfg.DGP['sigma2']
    lockpath=root/'.locks'/a.condition/a.variant/f'{seed}.lock'; lockpath.parent.mkdir(parents=True,exist_ok=True)
    with lockpath.open('a') as lock:
        try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            print('SKIP: replicate already running',flush=True); return
        if dest.exists():
            old=read_json(dest)
            if old.get('design_hash')!=signature or old.get('config_hash')!=canonical_hash(c) or old.get('code_hash')!=chash:
                raise RuntimeError('Existing result has different config/code; use a new root')
            if old.get('status')=='ok' or not a.retry_failed:
                print(f'SKIP existing {old.get("status")}: {dest}',flush=True); return
            write_json(root/'attempts'/a.condition/a.variant/f'seed_{seed}_{time.time_ns()}.json',old)
        # Same fit seed for 2000 and 6000 so the longer run extends the same stochastic setup.
        fit_seed=100000+seed
        row=dict(study_id=cfg.STUDY_ID,design_hash=signature,code_hash=chash,config_hash=canonical_hash(c),
                 condition=a.condition,scenario=a.condition,variant=a.variant,method=a.variant,
                 data_seed=seed,fit_seed=fit_seed,index=a.index,**cfg.DIMENSIONS,smoke=a.smoke,
                 training_config=c,status='failed',started_utc=datetime.now(timezone.utc).isoformat(),
                 job_id=os.environ.get('SLURM_ARRAY_JOB_ID',os.environ.get('SLURM_JOB_ID')),
                 array_task_id=os.environ.get('SLURM_ARRAY_TASK_ID'),hostname=os.uname().nodename,
                 python_torch_version=torch.__version__,device='cpu')
        stage_value='dataset'
        def stage(value):
            nonlocal stage_value; stage_value=value; print('STAGE='+value,flush=True)
        t0=time.perf_counter()
        try:
            dp=dataset_path(root,a.condition,seed)
            if not dp.exists(): raise FileNotFoundError(f'{dp}: run make_datasets.py first')
            data=load_dataset(dp); expected=canonical_hash(dataset_spec(a.condition,seed))
            if str(data['dataset_hash'].item())!=expected: raise RuntimeError('Dataset identity mismatch')
            row['dataset_hash']=expected; row['backend_files']=dependencies()
            if manifest_path.exists():
                pinned=read_json(manifest_path).get('backend_files',{})
                for name,item in row['backend_files'].items():
                    if name in pinned and pinned[name]['sha256']!=item['sha256']:
                        raise RuntimeError(f'External backend changed after submission: {name}')
            torch.set_num_threads(int(os.environ.get('SLURM_CPUS_PER_TASK','1')))
            from dss_runner import run
            result=run(data,c,fit_seed,stage); check_required(result)
            row.update(result); row['status']='ok'; row['stage']='done'
        except Exception as e:
            row.update(status='failed',stage=stage_value,error_type=type(e).__name__,error_message=str(e),
                       traceback_tail=traceback.format_exc()[-8000:])
            print(row['traceback_tail'],flush=True)
        row['wall_sec']=time.perf_counter()-t0; row['finished_utc']=datetime.now(timezone.utc).isoformat()
        row['maxrss_self_kb']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        row['maxrss_children_kb']=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
        write_json(dest,row)
        print(f'{row["status"]}: {a.condition} {a.variant} seed={seed}; {dest}',flush=True)
        if row['status']!='ok': raise SystemExit(2)

if __name__=='__main__': main()
