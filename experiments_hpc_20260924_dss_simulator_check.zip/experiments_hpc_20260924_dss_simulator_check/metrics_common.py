from __future__ import annotations
import math
import numpy as np
from scipy.stats import t as student_t
from sklearn.metrics import roc_auc_score


def finite_vector(value, name, size=None):
    a = np.asarray(value, dtype=np.float64).reshape(-1)
    if size is not None and a.size != size:
        raise ValueError(f'{name}: expected {size} values, found {a.size}')
    if not a.size or not np.isfinite(a).all():
        raise FloatingPointError(f'{name} contains NaN/Inf or is empty')
    return a


def function_metrics(signal, pred):
    signal = finite_vector(signal, 'signal')
    pred = finite_vector(pred, 'predictions', len(signal))
    with np.errstate(over='raise', invalid='raise'):
        mse = float(np.mean((pred - signal) ** 2))
        var = float(np.mean((signal - signal.mean()) ** 2))
    if var <= 0:
        raise ValueError('Test signal variance is zero')
    return dict(mse=mse, r2=1.0 - mse / var)


def selection_metrics(scores, truth, selected=None, threshold=0.5):
    truth = np.asarray(truth, dtype=bool).reshape(-1)
    scores = finite_vector(scores, 'feature scores', len(truth))
    selected = scores > threshold if selected is None else np.asarray(selected, dtype=bool).reshape(-1)
    if selected.shape != truth.shape or truth.all() or not truth.any():
        raise ValueError('Invalid selection dimensions or truth classes')
    tp = int(np.sum(selected & truth)); fp = int(np.sum(selected & ~truth))
    tn = int(np.sum(~selected & ~truth)); fn = int(np.sum(~selected & truth))
    return dict(tpr=tp/(tp+fn), fpr=fp/(fp+tn), accuracy=(tp+tn)/len(truth),
                auroc=float(roc_auc_score(truth, scores)),
                tp=tp, fp=fp, tn=tn, fn=fn, selected_support=int(selected.sum()),
                selected_indices=np.flatnonzero(selected).tolist())


def mean_ci(values, level=0.95, bounds=(None, None)):
    a = finite_vector(values, 'CI input')
    n = len(a)
    m = float(a.mean())
    if n < 2:
        return m, None, None
    # Scaled calculation avoids squaring large unscaled errors in the SD.
    scale = max(float(np.max(np.abs(a))), 1.0)
    sd = float(np.std(a / scale, ddof=1)) * scale
    delta = float(student_t.ppf((1 + level)/2, n-1)) * sd / math.sqrt(n)
    lo, hi = m - delta, m + delta
    if bounds[0] is not None: lo = max(float(bounds[0]), lo)
    if bounds[1] is not None: hi = min(float(bounds[1]), hi)
    if not all(np.isfinite(v) for v in (m, lo, hi)):
        raise FloatingPointError('Mean/CI overflow; no runs were silently removed')
    return m, lo, hi


def metric_bounds(metric):
    if metric in ('tpr', 'fpr', 'accuracy', 'auroc', 'dparam', 'd_edge', 'd_path'):
        return (0.0, 1.0)
    if metric == 'r2': return (None, 1.0)
    return (0.0, None)
