#!/usr/bin/env python3
import argparse
from pathlib import Path
import experiment_config as cfg
from io_common import HERE, ensure_design
from simulator import save_dataset


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--condition',choices=['all',*cfg.CONDITIONS],default='all')
    p.add_argument('--root',type=Path,default=HERE/'results')
    a=p.parse_args(); ensure_design(a.root)
    conditions=list(cfg.CONDITIONS) if a.condition=='all' else [a.condition]
    for condition in conditions:
        for seed in cfg.SEEDS: save_dataset(a.root,condition,seed)
        print(f'{condition}: {len(cfg.SEEDS)} datasets ready')

if __name__=='__main__': main()
