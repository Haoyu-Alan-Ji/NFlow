"""Frozen DSS-LVR-only simulator/optimization-length check."""
from copy import deepcopy

STUDY_ID = 'dss_simulator_length_check_20260924_v1'
DGP_VERSION = 'three_trig_dgps_v1'
SEEDS = tuple(range(400, 410))
CONDITIONS = {
    'sim1_additive_pairs': {
        'label': r'$\sin(x_1)+\cos(x_2)+\sin^2(x_3)+\cos^2(x_4)+x_5x_6+x_7x_8+x_9x_{10}$'
    },
    'sim2_mixed_pair': {
        'label': r'$\sin(x_1)\cos(x_2)+\sin^2(x_3)+\cos^2(x_4)+x_5x_6+x_7x_8+x_9x_{10}$'
    },
    'sim3_paired_hard': {
        'label': r'$\sin(x_1x_2)+\cos(x_3x_4)+\sin^2(x_5x_6)+\cos^2(x_7x_8)+\sin(x_9x_{10})+x_1x_2+x_3x_4$'
    },
}
VARIANTS = ('steps2000', 'steps6000')
DIMENSIONS = dict(n=2000, p=200, s=10)
DGP = dict(x_low=-2.5, x_high=2.5, train_fraction=0.8, sigma2=1.0,
           target_signal_sd=1.5)
HIDDEN_DIMS = (20, 20)
CI_LEVEL = 0.95
RESOURCES = dict(partition='msismall', cpus=1, memory='8G', walltime='24:00:00')

_BASE = dict(warmup=400, lr=3e-4, batch=None, draws=500, r_train=32,
    flow_layers=6, role_cycle=('U,V,tau', 'V,tau,U', 'tau,U,V'),
    flow_cycles=2, ordering='cyclic3', flow_hidden_units=128,
    flow_hidden_layers=2, scale_clip=2.0, gate='normalized_requ', gate_scale=1.0,
    init_sd=0.5, init_loc_jitter=0.05, grad_clip=5.0,
    slab_init='auto', slab_sd_ratio=0.1, slab_bias_sd=0.02, threshold=0.5)
TRAINING = {
    'steps2000': dict(_BASE, epochs=2000),
    'steps6000': dict(_BASE, epochs=6000),
}
METRICS = ('tpr', 'fpr', 'accuracy', 'auroc', 'mse', 'r2', 'dparam', 'd_edge', 'd_path', 'time_min')


def validate():
    assert len(SEEDS) == 10 and len(set(SEEDS)) == 10
    assert DIMENSIONS == {'n': 2000, 'p': 200, 's': 10}
    assert HIDDEN_DIMS == (20, 20)
    assert tuple(CONDITIONS) == ('sim1_additive_pairs', 'sim2_mixed_pair', 'sim3_paired_hard')
    assert VARIANTS == ('steps2000', 'steps6000')
    for name, spec in TRAINING.items():
        assert spec['epochs'] in (2000, 6000)
        assert spec['warmup'] == 400
        assert spec['lr'] == 3e-4
        assert spec['flow_layers'] == 3 * spec['flow_cycles'] == 6
        assert spec['ordering'] == 'cyclic3'
    assert DGP['target_signal_sd'] == 1.5 and DGP['sigma2'] == 1.0


def training_config(variant, smoke=False):
    validate()
    if variant not in TRAINING:
        raise ValueError(f'Unknown variant: {variant}')
    out = deepcopy(TRAINING[variant])
    out['hidden_dims'] = HIDDEN_DIMS
    if smoke:
        out.update(epochs=3, warmup=1, draws=5, r_train=2)
    return out


def design():
    validate()
    return dict(study_id=STUDY_ID, dgp_version=DGP_VERSION, seeds=SEEDS,
                conditions=CONDITIONS, variants=VARIANTS, dimensions=DIMENSIONS,
                dgp=DGP, hidden_dims=HIDDEN_DIMS, training=TRAINING,
                ci_level=CI_LEVEL, resources=RESOURCES)
