#!/usr/bin/env python3
from __future__ import annotations
import ast,inspect,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import experiment_config as cfg
from io_common import code_files
from paths import dependencies,import_dss_model


def main():
    cfg.validate()
    for src in code_files():
        if src.suffix=='.py': ast.parse(src.read_text(encoding='utf-8'),filename=str(src))
        elif src.suffix in ('.sh','.sbatch'): subprocess.run(['bash','-n',str(src)],check=True)
    print('OK syntax; DSS-only study = 3 conditions x 2 lengths x 10 seeds = 60 fits')
    import numpy,pandas,scipy,sklearn,torch
    torch.set_num_threads(1); print('OK Python stack; torch',torch.__version__)
    for name,data in dependencies().items(): print('OK',name,data['path'])
    md=import_dss_model(); init=inspect.signature(md.GroupedBNNVI.__init__).parameters
    for name in ('slab_init','iaf_ordering_scheme','K_flow'):
        if name not in init: raise RuntimeError(f'Current model2.py lacks {name}')
    from dss_runner import build_model
    c=cfg.training_config('steps2000',smoke=True); c['sigma2']=cfg.DGP['sigma2']
    torch.manual_seed(7); model=build_model(torch.randn(8,4),torch.randn(8),c,700001)
    loss=-model.elbo_draws(2)['elbo'].mean()
    if not torch.isfinite(loss): raise FloatingPointError('Non-finite DSS ELBO')
    loss.backward(); print('OK DSS finite ELBO/backward; 6-layer cyclic3 IAF')
    for v in cfg.VARIANTS:
        c=cfg.TRAINING[v]; print(f'{v}: epochs={c["epochs"]} warmup={c["warmup"]} lr={c["lr"]} draws={c["draws"]}')
    print('preflight passed')

if __name__=='__main__': main()
