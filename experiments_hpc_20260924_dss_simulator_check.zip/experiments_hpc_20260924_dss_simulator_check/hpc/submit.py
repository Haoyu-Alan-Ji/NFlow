#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,fcntl,os,re,shutil,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import experiment_config as cfg
from io_common import HERE,canonical_hash,code_files,code_hash,ensure_design,read_json,result_path,write_json
from paths import dependencies
from simulator import dataset_path,dataset_spec
from result_reader import read_one


def freeze(root,smoke):
    design_hash=ensure_design(root); chash=code_hash(); backend=dependencies(); path=root/'execution.json'
    if path.exists():
        old=read_json(path)
        if old['code_hash']!=chash or old['smoke']!=smoke or old['design_hash']!=design_hash:
            raise RuntimeError('Root already frozen with different code/settings')
        if {k:v['sha256'] for k,v in old['backend_files'].items()}!={k:v['sha256'] for k,v in backend.items()}:
            raise RuntimeError('DSS backend changed since submission')
    snapshot=root/'_code'/chash[:16]
    for src in code_files():
        dest=snapshot/src.relative_to(HERE); dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists(): shutil.copy2(src,dest)
    write_json(snapshot/'paths.local.json',{'project_root':str(HERE.parent)})
    write_json(path,dict(code_hash=chash,design_hash=design_hash,smoke=smoke,backend_files=backend,snapshot=str(snapshot)))
    return snapshot


def active_replicates(ledger):
    if not ledger.exists(): return set()
    with ledger.open() as f: rows=list(csv.DictReader(f,delimiter='\t'))
    if not rows: return set()
    proc=subprocess.run(['squeue','-u',os.environ.get('USER',''),'--array','--noheader','--format=%i'],text=True,capture_output=True,check=True)
    active=set(proc.stdout.split()); keep=set()
    for row in rows:
        for index in row['indices'].split(','):
            if f'{row["job_id"]}_{index}' in active: keep.add((row['condition'],row['variant'],int(index)))
    return keep


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--condition',choices=['all',*cfg.CONDITIONS],default='all')
    p.add_argument('--variant',choices=['all',*cfg.VARIANTS],default='all')
    p.add_argument('--root',type=Path)
    p.add_argument('--smoke',action='store_true'); p.add_argument('--retry-failed',action='store_true'); p.add_argument('--dry-run',action='store_true')
    a=p.parse_args(); cfg.validate()
    root=(a.root or HERE/('results_smoke' if a.smoke else 'results')).resolve()
    conditions=list(cfg.CONDITIONS) if a.condition=='all' else [a.condition]
    variants=list(cfg.VARIANTS) if a.variant=='all' else [a.variant]
    root.mkdir(parents=True,exist_ok=True)
    with (root/'.submit.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB); ensure_design(root)
        ledger=root/'submissions.tsv'; active=set() if a.dry_run else active_replicates(ledger)
        snapshot=HERE if a.dry_run else freeze(root,a.smoke); (root/'slurm').mkdir(exist_ok=True)
        plans=[]
        for c in conditions:
            for v in variants:
                indices=[]
                for index,seed in enumerate(cfg.SEEDS[:1] if a.smoke else cfg.SEEDS):
                    dp=dataset_path(root,c,seed)
                    if not dp.exists(): raise FileNotFoundError(f'{dp}: run make_datasets.py first')
                    meta=read_json(dp.with_suffix('.json'))
                    if meta.get('dataset_hash')!=canonical_hash(dataset_spec(c,seed)): raise RuntimeError(f'Dataset mismatch: {dp}')
                    path=result_path(root,c,v,seed)
                    if (c,v,index) in active: continue
                    if path.exists():
                        row=read_one(root,c,v,seed,smoke=a.smoke)
                        if row['status']=='invalid': raise RuntimeError(f'Invalid existing result {path}')
                        if row['status']=='ok': continue
                        if row['status']=='failed' and not a.retry_failed: continue
                    indices.append(index)
                if indices: plans.append((c,v,indices))
        submitted=0
        for c,v,indices in plans:
            array=','.join(map(str,indices)); jobname=f'dss_{c.replace("sim", "s")}_{v.replace("steps", "e")}' + ('_sm' if a.smoke else '')
            export=','.join(['ALL',f'NFLOW_CODE_DIR={snapshot}',f'NFLOW_RESULT_ROOT={root}',f'NFLOW_CONDITION={c}',f'NFLOW_VARIANT={v}',f'NFLOW_SMOKE={int(a.smoke)}',f'NFLOW_RETRY={int(a.retry_failed)}'])
            cmd=['sbatch','--parsable',f'--array={array}',f'--job-name={jobname}','--partition=msismall','--cpus-per-task=1','--mem=8G','--time=24:00:00',f'--output={root}/slurm/{jobname}_%A_%a.out',f'--error={root}/slurm/{jobname}_%A_%a.err',f'--export={export}',str(snapshot/'hpc'/'worker.sbatch')]
            if a.dry_run: print(' '.join(cmd)); submitted+=len(indices); continue
            proc=subprocess.run(cmd,text=True,capture_output=True)
            if proc.stderr: print(proc.stderr,end='',file=sys.stderr)
            if proc.returncode: raise RuntimeError(f'Submission failed for {c}/{v}')
            jid=proc.stdout.strip().split(';')[0]
            if not re.fullmatch(r'\d+',jid): raise RuntimeError(f'Unexpected sbatch output {proc.stdout!r}')
            exists=ledger.exists() and ledger.stat().st_size>0
            with ledger.open('a',newline='') as f:
                w=csv.writer(f,delimiter='\t')
                if not exists: w.writerow(['utc','job_id','condition','variant','indices','smoke'])
                w.writerow([datetime.now(timezone.utc).isoformat(),jid,c,v,array,int(a.smoke)])
            print(f'{c} {v}: {len(indices)} tasks -> {jid}',flush=True); submitted+=len(indices)
        print(f'{"Planned" if a.dry_run else "Submitted"} {submitted} tasks; DSS-LVR only, CPU, 8G, 24h.')
        print('Job ledger:',ledger)

if __name__=='__main__': main()
