#!/usr/bin/env python3
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import experiment_config as cfg
from io_common import HERE,ensure_design
from metrics_common import mean_ci,metric_bounds
from result_reader import read_one


def aggregate(root):
    ensure_design(root); outdir=Path(root)/'final'; outdir.mkdir(parents=True,exist_ok=True)
    summary=[]; audit=[]; raw=[]
    for c in cfg.CONDITIONS:
        for v in cfg.VARIANTS:
            rows=[read_one(root,c,v,s) for s in cfg.SEEDS]; raw.extend(rows)
            ok=[r for r in rows if r['status']=='ok']
            base=dict(condition=c,condition_label=cfg.CONDITIONS[c]['label'],variant=v,epochs=cfg.TRAINING[v]['epochs'],n_planned=10,n_fit=len(ok),n_failed=sum(r['status']=='failed' for r in rows),n_missing=sum(r['status']=='missing' for r in rows),n_invalid=sum(r['status']=='invalid' for r in rows),failed_seeds=';'.join(str(r['data_seed']) for r in rows if r['status']=='failed'))
            audit.append(base.copy()); out=base.copy()
            for key in cfg.METRICS:
                if ok:
                    m,lo,hi=mean_ci([r[key] for r in ok],cfg.CI_LEVEL,metric_bounds(key))
                else: m=lo=hi=None
                out[key]=m; out[key+'_lo']=lo; out[key+'_hi']=hi
            summary.append(out)
            print(f'{c} {v}: ok={len(ok)}/10 failed={base["n_failed"]} missing={base["n_missing"]} invalid={base["n_invalid"]}')
    pd.DataFrame(summary).to_csv(outdir/'summary_95ci.csv',index=False)
    pd.DataFrame(audit).to_csv(outdir/'completion_audit.csv',index=False)
    keep=['condition','variant','data_seed','status','stage','error_type','error_message','mse','r2','tpr','fpr','accuracy','auroc','dparam','d_edge','d_path','time_min']
    pd.DataFrame([{k:r.get(k) for k in keep} for r in raw]).to_csv(outdir/'runs_used_and_excluded.csv',index=False)
    # Compact human-readable comparison table.
    rows=[]
    for r in summary:
        def f(k,d=3):
            if r[k] is None: return '--'
            lo,hi=r[k+'_lo'],r[k+'_hi']
            if lo is None or hi is None: return f'{r[k]:.{d}f} [CI unavailable]'
            return f'{r[k]:.{d}f} [{lo:.{d}f}, {hi:.{d}f}]'
        rows.append(dict(condition=r['condition'],steps=r['epochs'],n_fit=r['n_fit'],TPR=f('tpr'),FPR=f('fpr'),Accuracy=f('accuracy'),AUROC=f('auroc'),MSE=f('mse'),R2=f('r2'),D_param=f('dparam',4),D_E=f('d_edge',4),D_pi=f('d_path',4),Time_min=f('time_min',1)))
    pd.DataFrame(rows).to_csv(outdir/'comparison_readable.csv',index=False)


def main():
    p=argparse.ArgumentParser(); p.add_argument('--root',type=Path,default=HERE/'results'); a=p.parse_args(); aggregate(a.root)
if __name__=='__main__': main()
