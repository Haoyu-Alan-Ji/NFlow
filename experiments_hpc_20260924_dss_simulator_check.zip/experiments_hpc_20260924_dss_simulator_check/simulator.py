"""Three fixed DSS-LVR test simulators; no teacher network or random function coefficients."""
from __future__ import annotations
import math
import os
import tempfile
from pathlib import Path
import numpy as np
import experiment_config as cfg
from io_common import canonical_hash, write_json


def raw_mean(X, condition):
    x = np.asarray(X, dtype=np.float64)
    if x.ndim != 2 or x.shape[1] < 10 or not np.isfinite(x).all():
        raise ValueError('X must be finite with at least 10 columns')
    x1,x2,x3,x4,x5,x6,x7,x8,x9,x10 = (x[:,j] for j in range(10))
    if condition == 'sim1_additive_pairs':
        return (np.sin(x1) + np.cos(x2) + np.sin(x3)**2 + np.cos(x4)**2
                + x5*x6 + x7*x8 + x9*x10)
    if condition == 'sim2_mixed_pair':
        return (np.sin(x1)*np.cos(x2) + np.sin(x3)**2 + np.cos(x4)**2
                + x5*x6 + x7*x8 + x9*x10)
    if condition == 'sim3_paired_hard':
        return (np.sin(x1*x2) + np.cos(x3*x4) + np.sin(x5*x6)**2 + np.cos(x7*x8)**2
                + np.sin(x9*x10) + x1*x2 + x3*x4)
    raise ValueError(f'Unknown condition: {condition}')


def true_mean(X, info):
    raw = raw_mean(X, info['condition'])
    return (raw - info['raw_signal_mean']) * info['target_signal_sd'] / info['raw_signal_sd']


def dataset_spec(condition, seed):
    cfg.validate()
    if condition not in cfg.CONDITIONS or seed not in cfg.SEEDS:
        raise ValueError('Unknown condition or seed')
    return dict(dgp_version=cfg.DGP_VERSION, condition=condition, seed=int(seed),
                dimensions=cfg.DIMENSIONS, dgp=cfg.DGP)


def simulate(condition, seed):
    spec = dataset_spec(condition, seed)
    n,p,s = (cfg.DIMENSIONS[k] for k in ('n','p','s'))
    g = cfg.DGP
    # Same X/noise/split for all three conditions at a given seed.
    X = np.random.default_rng(int(seed)).uniform(g['x_low'], g['x_high'], size=(n,p)).astype(np.float32)
    raw = raw_mean(X, condition)
    raw_mean_value = float(raw.mean())
    raw_sd = float(raw.std(ddof=0))
    if not np.isfinite(raw_sd) or raw_sd < 1e-12:
        raise ValueError('Degenerate raw signal')
    signal = ((raw - raw_mean_value) * g['target_signal_sd'] / raw_sd).astype(np.float32)
    noise = np.random.default_rng(int(seed)+777777).normal(size=n)
    y = (signal.astype(np.float64) + math.sqrt(g['sigma2']) * noise).astype(np.float32)
    perm = np.random.default_rng(int(seed)+123456).permutation(n)
    nt = int(round(g['train_fraction'] * n))
    truth = np.zeros(p, dtype=np.int8); truth[:s] = 1
    info = dict(spec, active_idx=list(range(s)), condition_label=cfg.CONDITIONS[condition]['label'],
                raw_signal_mean=raw_mean_value, raw_signal_sd=raw_sd,
                target_signal_sd=g['target_signal_sd'], sigma2=g['sigma2'],
                scaling='Center and rescale the full noiseless sample to SD=1.5 (ddof=0), then add N(0,1) noise.',
                dataset_hash=canonical_hash(spec))
    arrays = dict(X=X, y=y, signal=signal, feature_true=truth,
                  train_idx=perm[:nt], test_idx=perm[nt:], seed=np.asarray(seed),
                  condition=np.asarray(condition), dataset_hash=np.asarray(info['dataset_hash']))
    return arrays, info


def dataset_path(root, condition, seed):
    return Path(root)/'datasets'/condition/f'seed_{seed}.npz'


def save_dataset(root, condition, seed):
    dest = dataset_path(root, condition, seed)
    expected = canonical_hash(dataset_spec(condition, seed))
    if dest.exists():
        with np.load(dest, allow_pickle=False) as z:
            if str(z['dataset_hash'].item()) != expected:
                raise RuntimeError(f'Old/incompatible data at {dest}; use a new root')
        return dest
    arrays, info = simulate(condition, seed)
    dest.parent.mkdir(parents=True, exist_ok=True)
    fd,tmp = tempfile.mkstemp(suffix='.npz', dir=dest.parent); os.close(fd)
    try:
        np.savez_compressed(tmp, **arrays)
        write_json(dest.with_suffix('.json'), info)
        os.replace(tmp, dest)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)
    return dest


def load_dataset(path):
    with np.load(path, allow_pickle=False) as z:
        return {k:z[k] for k in z.files}
