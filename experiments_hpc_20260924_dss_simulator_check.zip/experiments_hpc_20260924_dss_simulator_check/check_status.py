#!/usr/bin/env python3
import argparse,csv,subprocess
from pathlib import Path
import experiment_config as cfg
from io_common import HERE
from result_reader import read_one


def show_slurm(root):
    ledger=Path(root)/'submissions.tsv'
    if not ledger.exists(): print('No submission ledger at',ledger); return
    with ledger.open() as f: entries=list(csv.DictReader(f,delimiter='\t'))
    ids=sorted(set(v['job_id'] for v in entries))
    if ids:
        cmd=['sacct','-X','-j',','.join(ids),'--starttime=2026-09-01','--format=JobID%24,JobName%28,State%20,Elapsed,ExitCode']
        print(' '.join(cmd),flush=True); subprocess.run(cmd,check=True)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--condition',choices=['all',*cfg.CONDITIONS],default='all')
    p.add_argument('--variant',choices=['all',*cfg.VARIANTS],default='all')
    p.add_argument('--root',type=Path,default=HERE/'results')
    p.add_argument('--smoke',action='store_true'); p.add_argument('--slurm',action='store_true')
    a=p.parse_args(); cfg.validate()
    if a.slurm: show_slurm(a.root)
    conditions=list(cfg.CONDITIONS) if a.condition=='all' else [a.condition]
    variants=list(cfg.VARIANTS) if a.variant=='all' else [a.variant]
    seeds=cfg.SEEDS[:1] if a.smoke else cfg.SEEDS; bad=False
    print('condition             variant      ok  failed  missing  invalid')
    for c in conditions:
        for v in variants:
            rows=[read_one(a.root,c,v,s,a.smoke) for s in seeds]
            counts={st:sum(r['status']==st for r in rows) for st in ('ok','failed','missing','invalid')}
            print(f'{c:21} {v:10} '+'  '.join(f'{counts[st]:5}' for st in counts))
            for r in rows:
                if r['status']!='ok':
                    bad=True; print(f'  seed={r["data_seed"]} {r["status"]}: {r.get("error_message","")[:220]}')
    if not bad: print('All requested results passed finite-metric validation.')
    raise SystemExit(2 if bad else 0)

if __name__=='__main__': main()
