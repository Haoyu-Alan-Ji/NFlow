import subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]

def main():
    subprocess.run([sys.executable,str(HERE/'make_datasets.py'),'--root',str(HERE/'_test_results')],check=True)
    p=subprocess.run([sys.executable,str(HERE/'hpc'/'submit.py'),'--condition','all','--variant','all','--root',str(HERE/'_test_results'),'--dry-run'],check=True,text=True,capture_output=True)
    assert 'Planned 60 tasks' in p.stdout
    print('submission plan test passed')
if __name__=='__main__': main()
