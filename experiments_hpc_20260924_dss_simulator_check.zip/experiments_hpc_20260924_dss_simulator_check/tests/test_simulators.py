import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import experiment_config as cfg
from simulator import raw_mean,simulate


def main():
    X=np.zeros((2,200),dtype=float)
    X[0,:10]=np.arange(1,11)/10
    x=X[0]
    expected1=np.sin(x[0])+np.cos(x[1])+np.sin(x[2])**2+np.cos(x[3])**2+x[4]*x[5]+x[6]*x[7]+x[8]*x[9]
    expected2=np.sin(x[0])*np.cos(x[1])+np.sin(x[2])**2+np.cos(x[3])**2+x[4]*x[5]+x[6]*x[7]+x[8]*x[9]
    expected3=np.sin(x[0]*x[1])+np.cos(x[2]*x[3])+np.sin(x[4]*x[5])**2+np.cos(x[6]*x[7])**2+np.sin(x[8]*x[9])+x[0]*x[1]+x[2]*x[3]
    assert np.allclose(raw_mean(X,'sim1_additive_pairs')[0],expected1)
    assert np.allclose(raw_mean(X,'sim2_mixed_pair')[0],expected2)
    assert np.allclose(raw_mean(X,'sim3_paired_hard')[0],expected3)
    for c in cfg.CONDITIONS:
        arrays,info=simulate(c,400)
        assert arrays['X'].shape==(2000,200) and arrays['feature_true'].sum()==10
        assert len(arrays['train_idx'])==1600 and len(arrays['test_idx'])==400
        assert abs(arrays['signal'].std()-1.5)<1e-5
    a,_=simulate('sim1_additive_pairs',400); b,_=simulate('sim2_mixed_pair',400); c,_=simulate('sim3_paired_hard',400)
    assert np.array_equal(a['X'],b['X']) and np.array_equal(a['X'],c['X'])
    assert np.array_equal(a['train_idx'],b['train_idx']) and np.allclose(a['y']-a['signal'],b['y']-b['signal'],atol=5e-7,rtol=0)
    print('simulator tests passed')
if __name__=='__main__': main()
