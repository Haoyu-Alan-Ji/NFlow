# Validation

The package includes exact formula tests for all three simulators, shared-design/noise checks across simulators, a 60-task dry-run submission check, Python syntax checks, and a DSS core ELBO/backward preflight on the HPC environment.
