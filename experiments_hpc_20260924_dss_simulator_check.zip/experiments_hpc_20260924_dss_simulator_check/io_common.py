from __future__ import annotations
import hashlib
import json
import math
import os
import tempfile
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def jsonable(value):
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    if isinstance(value, np.ndarray):
        return jsonable(value.tolist())
    if isinstance(value, np.generic):
        return jsonable(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Path):
        return str(value)
    return value


def canonical_hash(value):
    text = json.dumps(jsonable(value), sort_keys=True, separators=(',', ':'), allow_nan=False)
    return hashlib.sha256(text.encode()).hexdigest()


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def code_files():
    return sorted([*HERE.glob('*.py'), *HERE.glob('*.R'), *HERE.glob('hpc/*.py'),
                   *HERE.glob('hpc/*.sh'), *HERE.glob('hpc/*.sbatch')])


def code_hash():
    return canonical_hash({str(p.relative_to(HERE)): file_hash(p) for p in code_files()})


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.' + path.name, dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(jsonable(value), f, indent=2, allow_nan=False)
            f.write('\n')
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def ensure_design(root):
    import experiment_config as cfg
    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    payload = jsonable(cfg.design())
    signature = canonical_hash(payload)
    dest = root / 'study.json'
    if dest.exists():
        current = read_json(dest)
        if current.get('design_hash') != signature:
            raise RuntimeError('This result root has a different study design. Use a NEW --root; do not mix results.')
    else:
        write_json(dest, dict(design_hash=signature, design=payload))
    return signature


def result_path(root, scenario, method, seed):
    return Path(root) / 'jobs' / scenario / method / f'seed_{seed}.json'
