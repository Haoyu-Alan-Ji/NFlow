from pathlib import Path
import experiment_config as cfg
from io_common import canonical_hash, read_json, result_path
from run_task import check_required


def read_one(root, condition, variant, seed, smoke=False):
    path=result_path(root,condition,variant,seed)
    base=dict(condition=condition,scenario=condition,variant=variant,method=variant,data_seed=seed,**cfg.DIMENSIONS)
    if not path.exists(): return dict(base,status='missing',error_message='No terminal result JSON')
    try:
        row=read_json(path); c=cfg.training_config(variant,smoke); c['sigma2']=cfg.DGP['sigma2']
        for k,v in base.items():
            if row.get(k)!=v: raise ValueError(f'Result identity mismatch at {k}')
        if row.get('config_hash')!=canonical_hash(c) or row.get('design_hash')!=canonical_hash(cfg.design()):
            raise ValueError('Result training/DGP config mismatch')
        if bool(row.get('smoke'))!=smoke: raise ValueError('Smoke/formal mismatch')
        execution=Path(root)/'execution.json'
        if execution.exists() and row.get('code_hash')!=read_json(execution)['code_hash']:
            raise ValueError('Source-code snapshot mismatch')
        if row.get('status') not in ('ok','failed'): raise ValueError('Invalid status')
        if row['status']=='ok': check_required(row)
        return row
    except Exception as e:
        return dict(base,status='invalid',error_message=str(e),source=str(path))
