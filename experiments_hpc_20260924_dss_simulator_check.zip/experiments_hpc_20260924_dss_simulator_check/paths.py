"""Reuse the existing NFlow DSS core without copying or reinstalling it."""
from __future__ import annotations
import os
import sys
from pathlib import Path
from io_common import HERE, read_json, file_hash


def resolve_project():
    local = HERE/'paths.local.json'
    saved = read_json(local) if local.exists() else {}
    return Path(os.environ.get('NFLOW_PROJECT_ROOT', saved.get('project_root', str(HERE.parent)))).expanduser().resolve()


def dependencies():
    project = resolve_project()
    path = project/'Python'/'model2.py'
    if not path.is_file():
        raise FileNotFoundError(f'DSS_model2: {path}')
    return {'DSS_model2': {'path': str(path), 'sha256': file_hash(path)}}


def import_dss_model():
    project = resolve_project(); dependencies()
    sys.path.insert(0, str(project))
    from Python import model2
    return model2
