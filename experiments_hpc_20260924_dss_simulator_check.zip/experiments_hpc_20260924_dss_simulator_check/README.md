# DSS-LVR simulator / optimization-length check

Focused test only; no competitor methods, shallow network, MCMC reference, or additional sparsity scenarios.

## Frozen design

- `n=2000`, `p=200`, `s=10`; active predictors are `x1,...,x10`.
- `X_j ~ Uniform(-2.5,2.5)`, 80/20 train/test split.
- The noiseless signal is centered and rescaled to SD 1.5, followed by `N(0,1)` noise.
- MLP hidden dimensions: `(20,20)`.
- DSS-LVR: role-aware 6-layer cyclic3 IAF, normalized-ReQU, learning rate `3e-4`.
- Seeds: `400,...,409`.
- Two optimization lengths per dataset: 2000 and 6000 steps, both with the same 400-step force-all-on warmup and the same fit seed. Thus the length comparison changes optimization duration only.
- Total formal fits: `3 simulators x 10 seeds x 2 lengths = 60`.

## Simulators

1. `sim1_additive_pairs`
   `sin(x1) + cos(x2) + sin(x3)^2 + cos(x4)^2 + x5*x6 + x7*x8 + x9*x10`
2. `sim2_mixed_pair`
   `sin(x1)*cos(x2) + sin(x3)^2 + cos(x4)^2 + x5*x6 + x7*x8 + x9*x10`
3. `sim3_paired_hard`
   `sin(x1*x2) + cos(x3*x4) + sin(x5*x6)^2 + cos(x7*x8)^2 + sin(x9*x10) + x1*x2 + x3*x4`

The same X draw, noise draw, and train/test split are used across the three simulators for a given seed.

## HPC use

```bash
cd ~/NFlow/experiments_hpc_20260924_dss_simulator_check
source hpc/env.sh
python hpc/preflight.py
python tests/test_simulators.py
python make_datasets.py
```

Smoke test: one seed for all 3 x 2 configurations = 6 fits:

```bash
python make_datasets.py --root results_smoke
python hpc/submit.py --condition all --variant all --smoke
python check_status.py --condition all --variant all --smoke --root results_smoke --slurm
```

Formal 60-fit submission:

```bash
python hpc/submit.py --condition all --variant all
```

Live counts:

```bash
watch -n 30 'python check_status.py --condition all --variant all 2>/dev/null | tail -n 8'
```

Final aggregation:

```bash
python aggregate_results.py
column -s, -t < results/final/comparison_readable.csv | less -S
```
