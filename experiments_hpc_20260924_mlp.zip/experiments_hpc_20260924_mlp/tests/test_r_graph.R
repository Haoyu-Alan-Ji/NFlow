source('r_graph.R')
p <- 4L; h1 <- 2L; h2 <- 3L
r <- graph_stats(matrix(TRUE,h1,p),matrix(TRUE,h2,h1),matrix(TRUE,1L,h2),p,h1,h2,FALSE)
stopifnot(r$dparam==1,r$d_path==1,all(r$selected))
r <- graph_stats(matrix(FALSE,h1,p),matrix(FALSE,h2,h1),matrix(FALSE,1L,h2),p,h1,h2,FALSE)
stopifnot(r$dparam==0,r$d_path==0,!any(r$selected))
w1 <- matrix(FALSE,h1,p);w2 <- matrix(FALSE,h2,h1+p);wo <- matrix(FALSE,1L,h2+p)
wo[1,h2+2] <- TRUE
r <- graph_stats(w1,w2,wo,p,h1,h2,TRUE)
stopifnot(identical(which(r$selected),2L),r$d_path==1/(p*h1*h2+p*h2+p))
w1[1,1] <- TRUE; w2[2,1] <- TRUE;wo[1,2] <- TRUE
r <- graph_stats(w1,w2,wo,p,h1,h2,TRUE)
stopifnot(identical(which(r$selected),c(1L,2L)),r$d_path==2/(p*h1*h2+p*h2+p))
cat('R graph tests passed\n')
