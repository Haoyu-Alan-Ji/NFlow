"""Mock scheduler integration tests; no subprocess or real Slurm job is launched."""
from __future__ import annotations
import contextlib
import csv
import importlib.util
import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import experiment_config as cfg
from io_common import HERE,canonical_hash,code_files,code_hash,file_hash,read_json,write_json
from simulator import dataset_path,dataset_spec
spec=importlib.util.spec_from_file_location('nflow_submit',HERE/'hpc/submit.py')
submit=importlib.util.module_from_spec(spec);spec.loader.exec_module(submit)

class SubmissionTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.top=Path(self.tmp.name)
        self.result=self.top/'results';self.scheduler=[]
        project=self.top/'NFlow';(project/'Python').mkdir(parents=True)
        (project/'Python/model2.py').write_text('# mock dependency only, not a model\n')
        repo=self.top/'SS';repo.mkdir()
        for name in ('Group_Lasso_linear_layers_non_center.py','GHS_linear_layers_non_center_reg.py'):
            (repo/name).write_text('# mock dependency only, not a layer\n')
        self.env=dict(NFLOW_PROJECT_ROOT=str(project),NFLOW_SS_REPO=str(repo))
        # Submission reads only metadata; placeholders NEVER enter training.
        for scenario in cfg.SCENARIOS:
            for seed in cfg.SEEDS:
                p=dataset_path(self.result,scenario,seed);p.parent.mkdir(parents=True,exist_ok=True)
                p.write_bytes(b'MOCK ONLY')
                write_json(p.with_suffix('.json'),{'dataset_hash':canonical_hash(dataset_spec(scenario,seed))})
    def tearDown(self): self.tmp.cleanup()
    def fake_run(self,args,**kwargs):
        if args[0]=='sbatch':
            jid=str(900001+len(self.scheduler));self.scheduler.append(dict(job_id=jid,args=args))
            return subprocess.CompletedProcess(args,0,stdout=jid+'\n',stderr='')
        if args[0]=='squeue':
            active=[]
            for r in self.scheduler:
                array=next(a.split('=',1)[1] for a in r['args'] if a.startswith('--array='))
                active.extend(r['job_id']+'_'+i for i in array.split(','))
            return subprocess.CompletedProcess(args,0,stdout='\n'.join(active),stderr='')
        raise AssertionError('Unexpected subprocess: '+repr(args))
    def invoke(self,*args):
        out=io.StringIO()
        with patch.dict(os.environ,self.env),patch.object(sys,'argv',['submit.py','--root',str(self.result),*args]),patch.object(submit.subprocess,'run',side_effect=self.fake_run),contextlib.redirect_stdout(out):
            submit.main()
        return out.getvalue()
    def ledger(self):
        with (self.result/'submissions.tsv').open() as f:return list(csv.DictReader(f,delimiter='\t'))
    def test_complete_matrix_resources_snapshot_and_dedup(self):
        self.assertIn('Submitted 140 tasks',self.invoke('--scenario','main'))
        self.assertEqual(len(self.ledger()),7)
        for row in self.scheduler:
            args=row['args']
            self.assertIn('--partition=msismall',args);self.assertIn('--cpus-per-task=1',args)
            self.assertIn('--mem=8G',args);self.assertIn('--time=24:00:00',args)
            a=next(x for x in args if x.startswith('--array='))
            self.assertEqual(a,'--array='+','.join(map(str,range(20))))
            self.assertNotIn('%',a);self.assertFalse(any('gres' in a or 'cuda' in a for a in args))
        manifest=read_json(self.result/'execution.json');snap=Path(manifest['snapshot'])
        self.assertEqual(manifest['code_hash'],code_hash())
        snap_hash=canonical_hash({str(p.relative_to(HERE)):file_hash(snap/p.relative_to(HERE)) for p in code_files()})
        self.assertEqual(snap_hash,code_hash())
        self.assertIn('Submitted 0 tasks',self.invoke('--scenario','main'))
        self.assertEqual(len(self.ledger()),7)
        self.assertIn('Submitted 280 tasks',self.invoke('--scenario','appendix'))
        self.assertEqual(len(self.ledger()),21)
        self.assertEqual(sum(len(r['indices'].split(',')) for r in self.ledger()),420)
        self.assertIn('Submitted 0 tasks',self.invoke('--scenario','all'))
    def test_smoke_separate_and_executable_freeze(self):
        self.assertIn('Submitted 7 tasks',self.invoke('--scenario','main','--smoke'))
        self.assertTrue(all(r['indices']=='0' for r in self.ledger()))
        with self.assertRaisesRegex(RuntimeError,'NEW --root'):
            self.invoke('--scenario','main')
    def test_dry_run_not_submit(self):
        self.assertIn('Planned 420 tasks',self.invoke('--scenario','all','--dry-run'))
        self.assertEqual(self.scheduler,[]);self.assertFalse((self.result/'submissions.tsv').exists())

if __name__=='__main__':unittest.main(verbosity=2)
