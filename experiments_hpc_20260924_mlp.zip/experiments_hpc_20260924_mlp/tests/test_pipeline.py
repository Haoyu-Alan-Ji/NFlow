"""Fast local tests. No proprietary core or HPC services are required."""
from __future__ import annotations
import ast
import json
import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from scipy.stats import t
import experiment_config as cfg
from io_common import HERE, canonical_hash, code_hash, ensure_design, result_path, write_json
from simulator import fixed_groups,trig_raw,raw_mean,simulate,true_mean,save_dataset,load_dataset
from metrics_common import function_metrics,selection_metrics,mean_ci
from run_task import check_required
from result_reader import read_one
from aggregate_results import aggregate


class PipelineTests(unittest.TestCase):
    def test_design_and_lr_cap(self):
        cfg.validate()
        self.assertEqual(sum(7*len(cfg.SEEDS) for _ in cfg.SCENARIOS),420)
        original=cfg.TRAINING['LBBNN-FLOW']['lr']
        try:
            cfg.TRAINING['LBBNN-FLOW']['lr']=5e-4
            with self.assertRaises(ValueError): cfg.validate()
        finally: cfg.TRAINING['LBBNN-FLOW']['lr']=original

    def test_exact_trig(self):
        x=np.array([[.2,.4,.3,.8,.7,-.9,-.6,.5,.4,-.8],[1,2,3,4,5,6,7,8,9,10]],float)
        u=x[:,::2]*x[:,1::2]
        want=np.sin(u[:,0])+np.cos(u[:,1])+np.sin(u[:,2])**2+np.cos(u[:,3])**2+np.sin(u[:,4])
        np.testing.assert_allclose(trig_raw(x),want)
        np.testing.assert_allclose(raw_mean(x,np.arange(10),2,1),want+u[:,0]+u[:,1])
        self.assertFalse(np.allclose(np.sin(u[:,2])**2,np.sin(2*u[:,2])))

    def test_odd_groups(self):
        self.assertEqual(fixed_groups(5),[(0,1),(2,3),(4,)])
        x=np.arange(1,10,dtype=float)[None,:]/10
        want=trig_raw(x[:,:8])+np.sin(x[:,8])
        np.testing.assert_allclose(trig_raw(x),want)
        np.testing.assert_allclose(trig_raw(x[:,:3]),np.sin(x[:,0]*x[:,1])+np.cos(x[:,2]))
        with self.assertRaises(ValueError): raw_mean(x[:,:3],[0,1,2],2)

    def test_data_and_shared_null_extension(self):
        a,ma=simulate('main',400); b,mb=simulate('s02',400); c,mc=simulate('s20',400)
        self.assertEqual(a['X'].shape,(2000,200)); self.assertEqual(b['X'].shape,(2000,500))
        self.assertEqual(a['train_idx'].size,1600); self.assertEqual(a['test_idx'].size,400)
        self.assertEqual(int(c['feature_true'].sum()),40)
        np.testing.assert_array_equal(a['X'],b['X'][:,:200])
        np.testing.assert_array_equal(a['X'],c['X'])
        np.testing.assert_array_equal(a['y'],b['y'])
        np.testing.assert_array_equal(a['train_idx'],b['train_idx'])
        np.testing.assert_allclose(true_mean(a['X'],ma),a['signal'],rtol=1e-6,atol=1e-6)
        self.assertAlmostEqual(float(a['signal'].std()),1.5,places=6)
        self.assertNotIn('teacher_units',ma); self.assertNotIn('curve_X',a)
        modified=a['X'].copy(); modified[:,10:]+=100
        np.testing.assert_allclose(true_mean(modified,ma),true_mean(a['X'],ma))

    def test_reproducible_and_immutable(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=save_dataset(tmp,'main',400); a=load_dataset(dest)
            save_dataset(tmp,'main',400); b=load_dataset(dest)
            np.testing.assert_array_equal(a['y'],b['y'])
            ensure_design(tmp)
            study=Path(tmp)/'study.json'; j=json.loads(study.read_text()); j['design_hash']='old'; study.write_text(json.dumps(j))
            with self.assertRaises(RuntimeError): ensure_design(tmp)

    def test_metrics_ci(self):
        r=selection_metrics([.9,.8,.6,.1],[1,1,0,0])
        self.assertEqual(r['tpr'],1); self.assertEqual(r['fpr'],.5); self.assertEqual(r['accuracy'],.75)
        a=np.array([1.,2.,3.,4.]); m,lo,hi=mean_ci(a)
        delta=t.ppf(.975,3)*a.std(ddof=1)/2
        self.assertAlmostEqual(m,2.5); self.assertAlmostEqual(lo,m-delta); self.assertAlmostEqual(hi,m+delta)
        self.assertEqual(mean_ci([.8])[1:],(None,None))
        with self.assertRaises(FloatingPointError): mean_ci([1,np.nan])
        with self.assertRaises(FloatingPointError): function_metrics([1,2],[1,np.inf])
        with self.assertRaises(ValueError): function_metrics([1,2],[1])

    def test_results_and_partial_aggregation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); signature=ensure_design(root)
            for method in cfg.METHODS:
                c=cfg.training_config(method);c['sigma2']=cfg.DGP['sigma2']
                for i,seed in enumerate(cfg.SEEDS):
                    row=dict(scenario='main',method=method,data_seed=seed,n=2000,p=200,s=10,
                        smoke=False,design_hash=signature,code_hash=code_hash(),config_hash=canonical_hash(c),
                        status='ok',mse=1.0+i/100,r2=.5,tpr=.8,fpr=.1,accuracy=.8,auroc=.85,
                        dparam=.1,d_edge=.11 if method=='DSS-LVR' else None,d_path=.01,time_min=2.0)
                    if method in ('SS-GL','SS-GHS'):
                        row.update(tpr=None,fpr=None,accuracy=None,auroc=None)
                    if method=='LBBNN-FLOW' and i==0: row.update(status='failed',stage='prediction',error_message='invalid posterior scale')
                    if method=='ISLaB-FLOW' and i==0: row['mse']=1e23;row['r2']=-1e23
                    write_json(result_path(root,'main',method,seed),row)
            self.assertEqual(read_one(root,'main','LBBNN-FLOW',400)['status'],'failed')
            rows,audit=aggregate(root,['main'])
            lf=next(r for r in rows if r['method']=='LBBNN-FLOW'); self.assertEqual(lf['n_fit'],19)
            isl=next(r for r in rows if r['method']=='ISLaB-FLOW');self.assertEqual(isl['n_fit'],20);self.assertGreater(isl['mse'],1e21)
            gl=next(r for r in rows if r['method']=='SS-GL');self.assertIsNone(gl['accuracy']);self.assertIsNone(gl['d_edge'])
            text=(root/'final/main_table.tex').read_text()
            self.assertIn('95\\%',text);self.assertNotIn('AUPRC',text)
            self.assertNotIn('MCMC',text);self.assertNotIn('Shallow',text)

    def test_no_removed_workflows_and_r_lr(self):
        # No obsolete inference workflows are present in executable files.
        for name in ('dss_runner.py','run_task.py','simulator.py'):
            text=(HERE/name).read_text();tree=ast.parse(text)
            imports=[n.module or '' for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)]
            self.assertFalse(any('mcmc' in s for s in imports))
        r=(HERE/'run_r_single.R').read_text()
        self.assertNotIn('lr=.01',r);self.assertNotIn('lr=0.001',r)
        self.assertIn('lr=c$lr',r)
        worker=(HERE/'hpc/worker.sbatch').read_text()
        self.assertIn('--mem=8G',worker);self.assertIn('--time=24:00:00',worker)
        self.assertNotIn('gres',worker);self.assertNotIn('msigpu',worker)

if __name__=='__main__': unittest.main(verbosity=2)
