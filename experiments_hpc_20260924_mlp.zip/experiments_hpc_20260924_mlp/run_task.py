#!/usr/bin/env python3
"""One MLP replicate. Refuses duplicate concurrent writers and mixed configs."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import resource
import shutil
import tempfile
import time
import traceback
import numpy as np
import torch
import experiment_config as cfg
from io_common import HERE, canonical_hash, code_hash, ensure_design, read_json, result_path, write_json
from paths import dependencies
from simulator import dataset_path, dataset_spec, load_dataset


def check_required(row, method):
    needed = ['mse','r2','dparam','d_path','time_min']
    if method in cfg.SELECTION_METHODS: needed += ['tpr','fpr','accuracy','auroc']
    if method == 'DSS-LVR': needed += ['d_edge']
    for key in needed:
        if row.get(key) is None or not np.isfinite(float(row[key])):
            raise FloatingPointError(f'Required metric {key} is missing/non-finite')
    for key in ('tpr','fpr','accuracy','auroc','dparam','d_edge','d_path'):
        if row.get(key) is not None and not -1e-9 <= float(row[key]) <= 1+1e-9:
            raise ValueError(f'{key} is outside [0,1]')
    if row['mse'] < 0 or row['time_min'] < 0 or row['r2'] > 1+1e-9:
        raise ValueError('Invalid recovery/time metric')


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--scenario', required=True, choices=cfg.SCENARIOS)
    p.add_argument('--method', required=True, choices=cfg.METHODS)
    p.add_argument('--index', type=int, required=True)
    p.add_argument('--root', type=Path, default=HERE/'results')
    p.add_argument('--smoke', action='store_true')
    p.add_argument('--retry-failed', action='store_true')
    a = p.parse_args(); cfg.validate()
    if not 0 <= a.index < len(cfg.SEEDS): raise ValueError('Index must be 0..19')
    root = a.root.resolve()
    if a.smoke and root == HERE/'results':
        raise ValueError('Smoke tests need a separate --root, e.g. results_smoke')
    signature = ensure_design(root)
    chash = code_hash()
    manifest_path = root/'execution.json'
    if manifest_path.exists():
        manifest = read_json(manifest_path)
        if manifest['code_hash'] != chash or manifest['smoke'] != a.smoke:
            raise RuntimeError('Execution configuration does not match this root. Use a new root.')
    seed = cfg.SEEDS[a.index]; dest = result_path(root,a.scenario,a.method,seed)
    cfg_run = cfg.training_config(a.method,a.smoke); cfg_run['sigma2'] = cfg.DGP['sigma2']
    lockpath = root/'.locks'/a.scenario/a.method/f'{seed}.lock'; lockpath.parent.mkdir(parents=True,exist_ok=True)
    with lockpath.open('a') as lock:
        try:
            fcntl.flock(lock,fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print('SKIP: same replicate is already running',flush=True); return
        if dest.exists():
            old = read_json(dest)
            if old.get('design_hash') != signature or old.get('config_hash') != canonical_hash(cfg_run) or old.get('code_hash') != chash:
                raise RuntimeError('Existing result has a different config/code; use a new root')
            if old.get('status') == 'ok' or not a.retry_failed:
                print(f'SKIP existing {old.get("status")}: {dest}',flush=True); return
            archive = root/'attempts'/a.scenario/a.method/f'seed_{seed}_{time.time_ns()}.json'
            write_json(archive,old)
        dims = cfg.SCENARIOS[a.scenario]
        row = dict(study_id=cfg.STUDY_ID,design_hash=signature,code_hash=chash,config_hash=canonical_hash(cfg_run),
            scenario=a.scenario,method=a.method,data_seed=seed,fit_seed=100000+seed,index=a.index,
            n=dims['n'],p=dims['p'],s=dims['s'],smoke=a.smoke,training_config=cfg_run,
            status='failed',started_utc=datetime.now(timezone.utc).isoformat(),
            job_id=os.environ.get('SLURM_ARRAY_JOB_ID',os.environ.get('SLURM_JOB_ID')),
            array_task_id=os.environ.get('SLURM_ARRAY_TASK_ID'),hostname=os.uname().nodename,
            python_torch_version=torch.__version__,device='cpu')
        stage_value = 'dataset'
        def stage(value):
            nonlocal stage_value
            stage_value = value
            print('STAGE='+value,flush=True)
        t0 = time.perf_counter()
        try:
            dp = dataset_path(root,a.scenario,seed)
            if not dp.exists(): raise FileNotFoundError(f'{dp}: run make_datasets.py before submission')
            data = load_dataset(dp)
            expected = canonical_hash(dataset_spec(a.scenario,seed))
            if str(data['dataset_hash'].item()) != expected: raise RuntimeError('Dataset identity mismatch')
            row['dataset_hash'] = expected
            row['backend_files'] = dependencies(a.method)
            if manifest_path.exists():
                pinned = manifest.get('backend_files',{})
                for name, item in row['backend_files'].items():
                    if name in pinned and pinned[name]['sha256'] != item['sha256']:
                        raise RuntimeError(f'External backend changed after submission: {name}')
            threads = int(os.environ.get('SLURM_CPUS_PER_TASK','1'))
            torch.set_num_threads(threads)
            tempbase = root/'tmp'; tempbase.mkdir(exist_ok=True)
            with tempfile.TemporaryDirectory(prefix=f'{a.scenario}_{seed}_',dir=tempbase) as td:
                if a.method == 'DSS-LVR':
                    from dss_runner import run
                    result = run(data,cfg_run,row['fit_seed'],stage)
                elif a.method in ('SS-GL','SS-GHS'):
                    from ss_runner import run
                    result = run(data,cfg_run,row['fit_seed'],a.method,stage)
                else:
                    from r_runner import run
                    result = run(data,cfg_run,row['fit_seed'],a.method,stage,td)
            check_required(result,a.method)
            row.update(result); row['status']='ok'; row['stage']='done'
        except Exception as e:
            row.update(status='failed',stage=stage_value,error_type=type(e).__name__,error_message=str(e),
                       traceback_tail=traceback.format_exc()[-8000:])
            row.update(getattr(e,'details',{}))
            print(row['traceback_tail'],flush=True)
        row['wall_sec'] = time.perf_counter()-t0
        row['finished_utc'] = datetime.now(timezone.utc).isoformat()
        row['maxrss_self_kb'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        row['maxrss_children_kb'] = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
        write_json(dest,row)
        print(f'{row["status"]}: {a.scenario} {a.method} seed={seed}; {dest}',flush=True)
        if row['status'] != 'ok': raise SystemExit(2)

if __name__=='__main__': main()
