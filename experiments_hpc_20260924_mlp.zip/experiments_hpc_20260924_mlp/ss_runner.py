"""Regression wrappers for the installed official SS layer implementations.
No feature PIPs are fabricated for these native node-selection methods.
"""
from __future__ import annotations
import math
import sys
import time
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
from paths import resolve_paths
from metrics_common import function_metrics

def node_priors(n,p,h1,h2,out=1,constant=1e-9):
    L=2; su=(L+1)**2
    u0=su*(np.log(n)+np.log(L+1)+np.log(p+1)+np.log(h1)); u1=su*(np.log(n)+np.log(L+1)+np.log(h1+1)+np.log(h2)); u2=su*(np.log(n)+np.log(L+1)+np.log(h2+1)+np.log(max(out,1))); us=max(u0+u1+u2,1e-12)
    v0=(p+1)**2+np.log(h1+1)+np.log(h2+1)+L+np.log(h1)+np.log(p+1)+np.log(n)+np.log(us); v1=(h1+1)**2+np.log(p+1)+np.log(h2+1)+L+np.log(h2)+np.log(h1+1)+np.log(n)+np.log(us)
    return float(np.exp(-(np.log(h1)+constant*(p+1)*v0))),float(np.exp(-(np.log(h2)+constant*(h1+1)*v1)))
def import_layers(repo,method):
    sys.path.insert(0,str(Path(repo).resolve()))
    if method=='ss_gl':
        from Group_Lasso_linear_layers_non_center import SS_Group_Lasso_Node_layer, Group_Lasso_layer
        return SS_Group_Lasso_Node_layer,Group_Lasso_layer
    from GHS_linear_layers_non_center_reg import SS_GHS_Node_layer, GHS_layer
    return SS_GHS_Node_layer,GHS_layer
class GLNet(nn.Module):
    def __init__(self,p,h1,h2,node,out,g1,g2,temp=.5,sigma0=1.,lc=4.,ld=2.):
        super().__init__(); self.lc=lc; self.ld=ld; self.lm=nn.Parameter(torch.tensor([1.])); self.lr=nn.Parameter(torch.tensor([-6.])); self.l1=node(p,h1,self.lm,self.lr,temp=temp,gamma_prior=g1,sigma_0=sigma0); self.l2=node(h1,h2,self.lm,self.lr,temp=temp,gamma_prior=g2,sigma_0=sigma0); self.out=out(h2,1,self.lm,self.lr,sigma_0=sigma0); self.kg=torch.tensor(0.)
    def forward(self,x):
        s=F.softplus(self.lr); self.kg=(-self.lc*math.log(self.ld)+math.lgamma(self.lc)-self.lc*self.lm+self.ld*torch.exp(self.lm+s.square()/2)-torch.log(s)-1.41894).sum(); return self.out(F.relu(self.l2(F.relu(self.l1(x)))))
    def kl(self): return self.l1.kl+self.l2.kl+self.out.kl+self.kg
class GHSNet(nn.Module):
    def __init__(self,p,h1,h2,node,out,g1,g2,temp=.5,sigma0=1.,tau0=1.,tau1=1.,c=1.):
        super().__init__(); self.tau0=tau0; self.c=c; self.am=nn.Parameter(torch.tensor([1.])); self.ar=nn.Parameter(torch.tensor([-6.])); self.bm=nn.Parameter(torch.tensor([1.])); self.br=nn.Parameter(torch.tensor([-6.])); self.l1=node(p,h1,temp=temp,gamma_prior=g1,sigma_0=sigma0,tau_1=tau1); self.l2=node(h1,h2,temp=temp,gamma_prior=g2,sigma_0=sigma0,tau_1=tau1); self.out=out(h2,1,sigma_0=sigma0,tau_1=tau1); self.kg=torch.tensor(0.)
    def forward(self,x):
        sa=F.softplus(self.ar); sb=F.softplus(self.br); gs=torch.exp(.5*(self.am+self.bm)+.5*torch.sqrt(sa.square()+sb.square())*torch.randn_like(self.am)); ka=-math.log(self.tau0)+torch.exp(self.am+.5*sa.square())/self.tau0-.5*(self.am+2*torch.log(sa)+1.69315); kb=torch.exp(.5*sb.square()-self.bm)-.5*(2*torch.log(sb)-self.bm+1.69315); self.kg=(ka+kb).sum(); d={0:x,1:gs,2:self.c}; d=self.l1(d); d={0:F.relu(d[0]),1:d[1],2:d[2]}; d=self.l2(d); d={0:F.relu(d[0]),1:d[1],2:d[2]}; return self.out(d)[0]
    def kl(self): return self.l1.kl+self.l2.kl+self.out.kl+self.kg

def run(data, c, fit_seed, method, stage):
    if not 0 < c['lr'] <= 1e-4:
        raise ValueError('SS learning rate exceeds the study cap')
    torch.manual_seed(fit_seed); np.random.seed(fit_seed)
    _, repo = resolve_paths()
    tag = 'ss_gl' if method == 'SS-GL' else 'ss_ghs'
    stage('build_model'); node, output = import_layers(repo, tag)
    tr, te = data['train_idx'], data['test_idx']; p = data['X'].shape[1]; h1, h2 = c['hidden_dims']
    g1, g2 = node_priors(len(tr), p, h1, h2, constant=c['inclusion_constant'])
    if method == 'SS-GL':
        model = GLNet(p,h1,h2,node,output,g1,g2,temp=c['temp'],sigma0=c['sigma0'],lc=c['lambda_shape'],ld=c['lambda_rate'])
    else:
        model = GHSNet(p,h1,h2,node,output,g1,g2,temp=c['temp'],sigma0=c['sigma0'],tau0=c['tau0'],tau1=c['tau1'],c=c['c_reg'])
    X = torch.as_tensor(data['X'], dtype=torch.float32)
    y = torch.as_tensor(data['y'], dtype=torch.float32).reshape(-1, 1)
    ds = TensorDataset(X[tr], y[tr])
    dl = DataLoader(ds, batch_size=min(c['batch'], len(tr)), shuffle=True, num_workers=0,
                    generator=torch.Generator().manual_seed(fit_seed))
    opt = torch.optim.Adam(model.parameters(), lr=c['lr'])
    stage('training'); t0 = time.perf_counter()
    for ep in range(1, c['epochs']+1):
        model.train()
        for xb, yb in dl:
            opt.zero_grad(set_to_none=True)
            prediction = model(xb)
            if prediction.shape != yb.shape:
                raise ValueError('SS regression shape mismatch; broadcasting is forbidden')
            # Preserve the supplied adapter's mean-MSE + KL/N objective.
            loss = F.mse_loss(prediction, yb) + model.kl()/len(tr)
            if not bool(torch.isfinite(loss).all()):
                raise FloatingPointError(f'SS loss non-finite at epoch {ep}')
            loss.backward()
            for name, param in model.named_parameters():
                if param.grad is not None and not bool(torch.isfinite(param.grad).all()):
                    raise FloatingPointError(f'SS gradient non-finite: {name}, epoch {ep}')
            opt.step()
    train_sec = time.perf_counter()-t0
    stage('posterior_summary'); t1 = time.perf_counter()
    p1 = torch.sigmoid(model.l1.theta).detach().numpy(); p2 = torch.sigmoid(model.l2.theta).detach().numpy()
    if not np.isfinite(p1).all() or not np.isfinite(p2).all():
        raise FloatingPointError('SS node inclusion probabilities are non-finite')
    a1 = p1 > c['threshold']; a2 = p2 > c['threshold']
    # Retain the existing near-deterministic MPM gate implementation.
    with torch.no_grad():
        for layer, active in ((model.l1,a1),(model.l2,a2)):
            layer.theta.copy_(torch.where(torch.as_tensor(active), torch.full_like(layer.theta,30.), torch.full_like(layer.theta,-30.)))
    model.eval(); pred = []
    with torch.no_grad():
        for start in range(0,len(te),128):
            xb = X[te[start:start+128]]
            values = torch.stack([model(xb).reshape(-1) for _ in range(c['draws'])])
            if not bool(torch.isfinite(values).all()):
                raise FloatingPointError('SS posterior predictions are non-finite')
            pred.append(values.mean(0).numpy())
    retained = p*a1.sum() + a1.sum()*a2.sum() + a2.sum()
    candidate = p*h1 + h1*h2 + h2
    out = function_metrics(data['signal'][te], np.concatenate(pred))
    out.update(tpr=None, fpr=None, accuracy=None, auroc=None,
               dparam=float(retained/candidate), d_edge=None,
               d_path=float(a1.sum()*a2.sum()/(h1*h2)),
               time_min=train_sec/60, training_sec=train_sec, summary_sec=time.perf_counter()-t1,
               epochs_completed=c['epochs'], prior_node_inclusion=[g1,g2],
               n_retained_hidden=[int(a1.sum()),int(a2.sum())],
               node_pips=[p1.tolist(),p2.tolist()],
               prediction_rule='MC prediction with native node-MPM gates',
               density_rule='node-induced hard connectivity; dense input/output connections; weights only')
    return out
