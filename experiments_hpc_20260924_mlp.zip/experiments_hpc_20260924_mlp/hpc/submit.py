#!/usr/bin/env python3
"""Submit CPU arrays with no array-throttle suffix; records IDs persistently."""
from __future__ import annotations
import argparse
import csv
from datetime import datetime, timezone
import fcntl
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import experiment_config as cfg
from io_common import HERE, canonical_hash, code_files, code_hash, ensure_design, read_json, result_path, write_json
from paths import dependencies, resolve_paths
from simulator import dataset_path, dataset_spec
from result_reader import read_one

SHORT={'DSS-LVR':'dss','LBBNN-LRT':'lrt','LBBNN-FLOW':'lflow','ISLaB-FLOW':'islab','SS-GL':'ssgl','SS-GHS':'ssghs','IS-ANN-L1':'isann'}


def freeze(root,smoke):
    design_hash=ensure_design(root); chash=code_hash(); backend=dependencies()
    path=root/'execution.json'
    if path.exists():
        old=read_json(path)
        if old['code_hash']!=chash or old['smoke']!=smoke or old['design_hash']!=design_hash:
            raise RuntimeError('This root was submitted with different code/settings. Use a NEW --root.')
        if {k:v['sha256'] for k,v in old['backend_files'].items()}!={k:v['sha256'] for k,v in backend.items()}:
            raise RuntimeError('Backend changed since submission. Use a NEW --root.')
    snapshot=root/'_code'/chash[:16]
    for src in code_files():
        dest=snapshot/src.relative_to(HERE); dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists(): shutil.copy2(src,dest)
    project,repo=resolve_paths()
    write_json(snapshot/'paths.local.json',dict(project_root=str(project),ss_repo=str(repo)))
    write_json(path,dict(code_hash=chash,design_hash=design_hash,smoke=smoke,backend_files=backend,snapshot=str(snapshot)))
    return snapshot


def active_replicates(ledger):
    if not ledger.exists(): return set()
    with ledger.open() as f: rows=list(csv.DictReader(f,delimiter='\t'))
    if not rows: return set()
    proc=subprocess.run(['squeue','-u',os.environ.get('USER',''),'--array','--noheader','--format=%i'],text=True,capture_output=True,check=True)
    active=set(proc.stdout.split()); keep=set()
    for row in rows:
        for index in row['indices'].split(','):
            if f'{row["job_id"]}_{index}' in active:
                keep.add((row['scenario'],row['method'],int(index)))
    return keep


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--scenario',choices=['all','appendix',*cfg.SCENARIOS],default='main')
    p.add_argument('--root',type=Path)
    p.add_argument('--methods',default=','.join(cfg.METHODS))
    p.add_argument('--smoke',action='store_true')
    p.add_argument('--retry-failed',action='store_true')
    p.add_argument('--dry-run',action='store_true')
    a=p.parse_args(); cfg.validate()
    root=(a.root or HERE/('results_smoke' if a.smoke else 'results')).resolve()
    methods=tuple(x.strip() for x in a.methods.split(','))
    if len(set(methods))!=len(methods) or any(m not in cfg.METHODS for m in methods): raise ValueError('Invalid methods')
    scenarios=list(cfg.SCENARIOS) if a.scenario=='all' else (['s20','s02'] if a.scenario=='appendix' else [a.scenario])
    if a.smoke and (len(scenarios)!=1 or scenarios[0]!='main'): raise ValueError('The smoke suite uses main only')
    root.mkdir(parents=True,exist_ok=True)
    with (root/'.submit.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX | fcntl.LOCK_NB)
        ensure_design(root)
        ledger=root/'submissions.tsv'
        active=set() if a.dry_run else active_replicates(ledger)
        snapshot=HERE if a.dry_run else freeze(root,a.smoke)
        (root/'slurm').mkdir(exist_ok=True)
        plans=[]
        for scenario in scenarios:
            for method in methods:
                indices=[]
                for index,seed in enumerate(cfg.SEEDS[:1] if a.smoke else cfg.SEEDS):
                    dp=dataset_path(root,scenario,seed)
                    if not dp.exists(): raise FileNotFoundError(f'{dp}: run make_datasets.py --root {root}')
                    meta=read_json(dp.with_suffix('.json'))
                    if meta.get('dataset_hash')!=canonical_hash(dataset_spec(scenario,seed)):
                        raise RuntimeError(f'Dataset metadata mismatch: {dp}')
                    path=result_path(root,scenario,method,seed)
                    if (scenario,method,index) in active: continue
                    if path.exists():
                        row=read_one(root,scenario,method,seed,smoke=a.smoke)
                        if row['status']=='invalid':
                            raise RuntimeError(f'Invalid existing result {path}: {row["error_message"]}')
                        if row['status']=='ok': continue
                        if row['status']=='failed' and not a.retry_failed: continue
                    indices.append(index)
                if indices: plans.append((scenario,method,indices))
        submitted=0
        for scenario,method,indices in plans:
            array=','.join(map(str,indices))
            assert '%' not in array
            jobname=f'nf_{scenario}_{SHORT[method]}' + ('_sm' if a.smoke else '')
            export=','.join(['ALL',f'NFLOW_CODE_DIR={snapshot}',f'NFLOW_RESULT_ROOT={root}',
                f'NFLOW_SCENARIO={scenario}',f'NFLOW_METHOD={method}',f'NFLOW_SMOKE={int(a.smoke)}',f'NFLOW_RETRY={int(a.retry_failed)}'])
            cmd=['sbatch','--parsable',f'--array={array}',f'--job-name={jobname}',
                 '--partition=msismall','--cpus-per-task=1','--mem=8G','--time=24:00:00',
                 f'--output={root}/slurm/{jobname}_%A_%a.out',f'--error={root}/slurm/{jobname}_%A_%a.err',
                 f'--export={export}',str(snapshot/'hpc'/'worker.sbatch')]
            if a.dry_run:
                print(' '.join(cmd)); submitted+=len(indices); continue
            proc=subprocess.run(cmd,text=True,capture_output=True)
            if proc.stderr: print(proc.stderr,end='',file=sys.stderr)
            if proc.returncode: raise RuntimeError(f'Submission failed for {method}; previous accepted IDs are in {ledger}')
            jid=proc.stdout.strip().split(';')[0]
            if not re.fullmatch(r'\d+',jid): raise RuntimeError(f'Unexpected sbatch output {proc.stdout!r}; check squeue before resubmitting')
            exists=ledger.exists() and ledger.stat().st_size>0
            with ledger.open('a',newline='') as f:
                w=csv.writer(f,delimiter='\t')
                if not exists: w.writerow(['utc','job_id','scenario','method','indices','smoke'])
                w.writerow([datetime.now(timezone.utc).isoformat(),jid,scenario,method,array,int(a.smoke)])
            print(f'{scenario} {method}: {len(indices)} tasks -> {jid}',flush=True); submitted+=len(indices)
        print(f'{"Planned" if a.dry_run else "Submitted"} {submitted} tasks; CPU, 8G, 24h; no user array concurrency cap.')
        print(f'Job ledger: {ledger}')

if __name__=='__main__': main()
