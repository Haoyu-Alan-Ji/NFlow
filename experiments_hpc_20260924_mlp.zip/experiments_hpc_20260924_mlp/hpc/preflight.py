#!/usr/bin/env python3
"""Static + CPU/R runtime checks. No fit, result or posterior reference is generated."""
from __future__ import annotations
import ast
import importlib
import inspect
import json
import os
from pathlib import Path
import subprocess
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import experiment_config as cfg
from io_common import HERE, code_files
from paths import dependencies, resolve_paths, import_dss_model


def main():
    cfg.validate()
    for source in code_files():
        if source.suffix=='.py': ast.parse(source.read_text(encoding='utf-8'),filename=str(source))
        elif source.suffix in ('.sh','.sbatch'): subprocess.run(['bash','-n',str(source)],check=True)
    print('OK Python/bash syntax; pure MLP, 3 scenarios x 7 methods x 20 seeds = 420 fits')
    for m in ('numpy','pandas','scipy','sklearn','torch'):
        mod=importlib.import_module(m); print('OK',m,getattr(mod,'__version__',''))
    import torch
    torch.set_num_threads(1)
    print('INFO execution is CPU-only; no GPU or CUDA request is used.')
    for name,data in dependencies().items(): print('OK',name,data['path'])
    md=import_dss_model()
    init=inspect.signature(md.GroupedBNNVI.__init__).parameters
    for name in ('slab_init','iaf_ordering_scheme','K_flow'):
        if name not in init: raise RuntimeError(f'Current model2.py lacks {name}')
    c=cfg.training_config('DSS-LVR',smoke=True); c['sigma2']=cfg.DGP['sigma2']
    from dss_runner import build_model
    torch.manual_seed(7)
    model=build_model(torch.randn(8,4),torch.randn(8),c,700001)
    loss=-model.elbo_draws(2)['elbo'].mean()
    if not torch.isfinite(loss): raise FloatingPointError('DSS core ELBO is not finite')
    loss.backward()
    for par in model.parameters():
        if par.grad is not None and not torch.isfinite(par.grad).all(): raise FloatingPointError('DSS core gradient is not finite')
    del model
    print('OK DSS core: finite CPU ELBO/backward, 6 cyclic3 layers; no MCMC import required')
    project,repo=resolve_paths()
    from ss_runner import import_layers
    for m in ('ss_gl','ss_ghs'): import_layers(repo,m)
    print('OK both installed official SS layer modules import')
    rr=str(HERE/'run_r_single.R'); rg=str(HERE/'r_graph.R')
    expr=f'''
invisible(parse(file={json.dumps(rr)})); invisible(parse(file={json.dumps(rg)}))
stopifnot(getRversion() == "4.4.2")
suppressPackageStartupMessages({{library(torch);library(LBBNN);library(jsonlite)}})
stopifnot(as.character(packageVersion("LBBNN")) == "{cfg.R_PACKAGE_VERSION}")
stopifnot(identical(as.numeric(as.array(torch_tensor(c(1,2))+1)),c(2,3)))
for(p in c("torch","LBBNN","jsonlite","igraph","ggplot2","coro","svglite")) {{
  stopifnot(requireNamespace(p,quietly=TRUE)); cat(p,as.character(packageVersion(p)),find.package(p),"\\n")
}}
cat("R_PARSE_AND_STACK_OK\\n")
'''
    try:
        proc=subprocess.run(['Rscript','-e',expr],capture_output=True,text=True,timeout=180)
    except FileNotFoundError as e:
        raise RuntimeError('Rscript not found. Run: source hpc/env.sh') from e
    if proc.returncode or 'R_PARSE_AND_STACK_OK' not in proc.stdout:
        print(proc.stdout); print(proc.stderr)
        raise RuntimeError('R parse/runtime check failed; see full output above')
    print(proc.stdout)
    print('OK training configurations:')
    for method,c in cfg.TRAINING.items():
        print(f'  {method}: epochs={c["epochs"]} lr={c["lr"]} batch={c["batch"]} draws={c["draws"]}')
    print('preflight passed')

if __name__=='__main__': main()
