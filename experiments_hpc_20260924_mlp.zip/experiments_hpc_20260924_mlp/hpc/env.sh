#!/usr/bin/env bash
# Source in the login shell or worker. Do not copy/reinstall the existing libraries.
set +u
source activate nf311
set -u
unset LD_PRELOAD
unset TORCH_VERIFY_LOAD
module unload R/4.2.2-gcc-8.2.0-vp7tyde 2>/dev/null || true
module load r-rich/4.4.2_msi1.2
export R_LIBS_USER="$HOME/R/r-rich-4.4.2"
export OMP_NUM_THREADS="${SLURM_CPUS_PER_TASK:-1}"
export MKL_NUM_THREADS="${SLURM_CPUS_PER_TASK:-1}"
export OPENBLAS_NUM_THREADS="${SLURM_CPUS_PER_TASK:-1}"
export NUMEXPR_NUM_THREADS="${SLURM_CPUS_PER_TASK:-1}"
export PYTHONUNBUFFERED=1
