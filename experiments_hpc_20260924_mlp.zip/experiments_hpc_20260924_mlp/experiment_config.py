"""Frozen MLP-only comparison. Edit here only, then use a NEW result root."""
from copy import deepcopy

STUDY_ID = 'paired_trig_mlp_20260924_v1'
DGP_VERSION = 'paired_product_trig_v1'
SEEDS = tuple(range(400, 420))
METHODS = ('DSS-LVR', 'LBBNN-LRT', 'LBBNN-FLOW', 'ISLaB-FLOW', 'SS-GL', 'SS-GHS', 'IS-ANN-L1')
SCENARIOS = {
    'main': {'n': 2000, 'p': 200, 's': 10, 'label': 'Main: 5% active'},
    's20': {'n': 2000, 'p': 200, 's': 40, 'label': 'Appendix: 20% active'},
    's02': {'n': 2000, 'p': 500, 's': 10, 'label': 'Appendix: 2% active'},
}
DGP = dict(x_low=-2.5, x_high=2.5, train_fraction=0.8, sigma2=1.0,
           target_signal_sd=1.5, interaction_count=2, interaction_scale=1.0,
           design_width=500)
HIDDEN_DIMS = (20, 20)
CI_LEVEL = 0.95
R_MODULE = 'r-rich/4.4.2_msi1.2'
R_LIB_SUBDIR = 'R/r-rich-4.4.2'
R_PACKAGE_VERSION = '0.1.6'
RESOURCES = dict(partition='msismall', cpus=1, memory='8G', walltime='24:00:00')
TRAINING = {
    'DSS-LVR': dict(epochs=2000, warmup=400, lr=3e-4, batch=None, draws=500,
        r_train=32, flow_layers=6, role_cycle=('U,V,tau', 'V,tau,U', 'tau,U,V'),
        flow_cycles=2, ordering='cyclic3', flow_hidden_units=128,
        flow_hidden_layers=2, scale_clip=2.0, gate='normalized_requ', gate_scale=1.0,
        init_sd=0.5, init_loc_jitter=0.05, grad_clip=5.0,
        slab_init='auto', slab_sd_ratio=0.1, slab_bias_sd=0.02, threshold=0.5),
    'LBBNN-LRT': dict(epochs=2000, lr=1e-4, batch=128, draws=500, input_skip=False,
        flow=False, prior=0.5, std=1.0, inclusion_inits='polarized',
        num_transforms=2, flow_dims=(50, 50), weight_init='he'),
    'LBBNN-FLOW': dict(epochs=2000, lr=1e-4, batch=128, draws=500, input_skip=False,
        flow=True, prior=0.5, std=1.0, inclusion_inits='polarized',
        num_transforms=2, flow_dims=(50, 50), weight_init='he'),
    'ISLaB-FLOW': dict(epochs=2000, lr=1e-4, batch=128, draws=500, input_skip=True,
        flow=True, prior=0.5, std=1.0, inclusion_inits='polarized',
        num_transforms=2, flow_dims=(50, 50), weight_init='he'),
    # Retain the previously requested conservative 4000 / 1e-4 / 1024 schedule.
    'SS-GL': dict(epochs=4000, lr=1e-4, batch=1024, draws=100,
        temp=0.5, sigma0=1.0, lambda_shape=4.0, lambda_rate=2.0,
        inclusion_constant=1e-9, threshold=0.5),
    'SS-GHS': dict(epochs=4000, lr=1e-4, batch=1024, draws=100,
        temp=0.5, sigma0=1.0, tau0=1.0, tau1=1.0, c_reg=1.0,
        inclusion_constant=1e-9, threshold=0.5),
    'IS-ANN-L1': dict(epochs=2000, lr=1e-4, batch=128, draws=1,
        input_skip=True, l1=0.01, weight_cutoff=0.005),
}
METRICS = ('tpr', 'fpr', 'accuracy', 'auroc', 'mse', 'r2', 'dparam', 'd_edge', 'd_path', 'time_min')
SELECTION_METHODS = tuple(m for m in METHODS if m not in ('SS-GL', 'SS-GHS'))


def validate():
    assert len(SEEDS) == 20 and len(set(SEEDS)) == 20
    assert len(METHODS) == 7 and HIDDEN_DIMS == (20, 20)
    assert TRAINING['DSS-LVR']['epochs'] == 2000
    assert TRAINING['DSS-LVR']['warmup'] == 400
    assert TRAINING['DSS-LVR']['lr'] == 3e-4
    assert TRAINING['DSS-LVR']['ordering'] == 'cyclic3'
    assert TRAINING['DSS-LVR']['flow_layers'] == 3 * TRAINING['DSS-LVR']['flow_cycles'] == 6
    for method, spec in TRAINING.items():
        assert spec['epochs'] > 0 and spec['draws'] > 0
        if method != 'DSS-LVR':
            if not 0 < spec['lr'] <= 1e-4:
                raise ValueError(f'{method}: learning rate must be in (0, 1e-4].')
    for name, spec in SCENARIOS.items():
        assert 0 < spec['s'] < spec['p'] <= DGP['design_width']
        assert DGP['interaction_count'] <= spec['s'] // 2
    assert DGP['interaction_scale'] == 1.0


def training_config(method, smoke=False):
    validate()
    out = deepcopy(TRAINING[method])
    out['hidden_dims'] = HIDDEN_DIMS
    if smoke:
        out['epochs'] = 3
        out['draws'] = 5
        if method == 'DSS-LVR':
            out.update(warmup=1, r_train=2)
    return out


def design():
    validate()
    return dict(study_id=STUDY_ID, dgp_version=DGP_VERSION, seeds=SEEDS,
                methods=METHODS, scenarios=SCENARIOS, dgp=DGP,
                hidden_dims=HIDDEN_DIMS, training=TRAINING, ci_level=CI_LEVEL,
                r_module=R_MODULE, r_package_version=R_PACKAGE_VERSION)
