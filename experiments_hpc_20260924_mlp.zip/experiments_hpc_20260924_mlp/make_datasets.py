#!/usr/bin/env python3
from pathlib import Path
import argparse
import experiment_config as cfg
from io_common import HERE, ensure_design
from simulator import save_dataset


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--scenario', choices=['all', *cfg.SCENARIOS], default='all')
    p.add_argument('--root', type=Path, default=HERE / 'results')
    a = p.parse_args(); ensure_design(a.root)
    scenarios = cfg.SCENARIOS if a.scenario == 'all' else [a.scenario]
    for scenario in scenarios:
        for seed in cfg.SEEDS:
            save_dataset(a.root, scenario, seed)
        print(f'{scenario}: {len(cfg.SEEDS)} immutable datasets ready; {cfg.SCENARIOS[scenario]}')

if __name__ == '__main__':
    main()
