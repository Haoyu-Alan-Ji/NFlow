# Validation performed while preparing this folder

- Eight local pipeline tests passed: exact product-trig formula, squared (not doubled-frequency) functions, fixed pairs and odd singleton groups, deterministic/common-design data, dimensions/splits/scaling, learning-rate cap, predictor-selection accuracy, Student-t intervals, unsupported metrics, failed-run exclusion, finite-extreme-run retention, and obsolete-workflow removal.
- Three mocked scheduler integration tests passed: 140 main plus 280 appendix tasks, CPU/8G/24h resource declarations, no user array concurrency throttle, persistent job IDs, active-task deduplication, identical code snapshots, smoke/formal separation, and dry-run behavior. No real Slurm jobs were submitted by these tests.
- All packaged Python sources passed AST syntax parsing; all shell and Slurm scripts passed bash -n.
- A representative table containing long scientific-notation values and confidence intervals was compiled with pdfLaTeX and visually inspected. Artificial format-test data and PDFs are NOT packaged as experimental results.
- The R sources were checked for balanced delimiters, but there is no R runtime in the preparation environment. They have NOT been claimed to pass a local R parser or native R training test. hpc/preflight.py runs the actual R parser, package/version, and tensor checks on MSI; tests/test_r_graph.R checks path accounting there.
- The installed DSS core and external SS layers are reused by absolute path and hashed at submission. No 2000/4000-epoch native fits, full convergence checks, or HPC experiments were executed during packaging. The optional seven-method smoke suite validates those installed backends end-to-end before formal runs.

The test suites use temporary fixtures only. The 420 formal results do not yet exist in this archive.
