"""Fixed paired-product trig DGP; no hidden teacher network or curve artifacts."""
from __future__ import annotations
import json
import math
import os
import tempfile
from pathlib import Path
import numpy as np
import experiment_config as cfg
from io_common import canonical_hash, read_json, write_json


def fixed_groups(s):
    if isinstance(s, bool) or int(s) != s or s < 1:
        raise ValueError('s must be a positive integer')
    return [tuple(range(j, min(j + 2, s))) for j in range(0, s, 2)]


def trig_raw(X_active):
    xa = np.asarray(X_active, dtype=np.float64)
    if xa.ndim != 2 or xa.shape[1] < 1 or not np.isfinite(xa).all():
        raise ValueError('X_active must be a finite n-by-s matrix with s >= 1')
    result = np.zeros(xa.shape[0], dtype=np.float64)
    for h, group in enumerate(fixed_groups(xa.shape[1])):
        u = xa[:, group[0]].copy()
        if len(group) == 2:
            u *= xa[:, group[1]]
        if h == 1:
            term = np.cos(u)
        elif h == 2:
            term = np.sin(u) ** 2
        elif h == 3:
            term = np.cos(u) ** 2
        else:
            term = np.sin(u)
        result += term
    return result


def raw_mean(X, active_idx, interaction_count=2, interaction_scale=1.0):
    x = np.asarray(X, dtype=np.float64)
    active = np.asarray(active_idx, dtype=np.int64)
    if x.ndim != 2 or active.ndim != 1 or len(set(active.tolist())) != len(active):
        raise ValueError('Invalid design/active indices')
    if len(active) < 1 or active.min() < 0 or active.max() >= x.shape[1]:
        raise ValueError('Active index out of range')
    if int(interaction_count) != interaction_count or not 0 <= interaction_count <= len(active) // 2:
        raise ValueError('interaction_count exceeds available complete pairs; it is not silently truncated')
    xa = x[:, active]
    out = trig_raw(xa)
    for h in range(int(interaction_count)):
        out += float(interaction_scale) * xa[:, 2*h] * xa[:, 2*h + 1]
    return out


def true_mean(X, info):
    """Evaluate with frozen DGP/scaling constants, not the current config."""
    raw = raw_mean(X, info['active_idx'], info['interaction_count'], info['interaction_scale'])
    return (raw - info['raw_signal_mean']) * info['target_signal_sd'] / info['raw_signal_sd']


def dataset_spec(scenario, seed):
    cfg.validate()
    if scenario not in cfg.SCENARIOS or seed not in cfg.SEEDS:
        raise ValueError('Unknown scenario or seed')
    return dict(dgp_version=cfg.DGP_VERSION, scenario=scenario, seed=int(seed),
                dimensions=cfg.SCENARIOS[scenario], dgp=cfg.DGP)


def simulate(scenario, seed):
    spec = dataset_spec(scenario, seed)
    n, p, s = (spec['dimensions'][k] for k in ('n', 'p', 's'))
    g = cfg.DGP
    # Common 500-column draw preserves identical first 200 columns across p=200/500.
    x_rng = np.random.default_rng(int(seed))
    full = x_rng.uniform(g['x_low'], g['x_high'], size=(n, g['design_width'])).astype(np.float32)
    X = full[:, :p].copy()
    active = np.arange(s, dtype=np.int64)
    raw = raw_mean(X, active, g['interaction_count'], g['interaction_scale'])
    sd = float(raw.std(ddof=0))
    if not np.isfinite(sd) or sd < 1e-12:
        raise ValueError('Degenerate raw signal')
    signal = ((raw - raw.mean()) * g['target_signal_sd'] / sd).astype(np.float32)
    noise_rng = np.random.default_rng(int(seed) + 777777)
    y = (signal.astype(np.float64) + math.sqrt(g['sigma2']) * noise_rng.normal(size=n)).astype(np.float32)
    idx = np.random.default_rng(int(seed) + 123456).permutation(n)
    nt = int(round(g['train_fraction'] * n))
    truth = np.zeros(p, dtype=np.int8); truth[active] = 1
    info = dict(spec, active_idx=active.tolist(), groups=[list(v) for v in fixed_groups(s)],
                interaction_count=g['interaction_count'], interaction_scale=g['interaction_scale'],
                interaction_pairs=[[2*h, 2*h+1] for h in range(g['interaction_count'])],
                component_functions=['sin', 'cos', 'sin_squared', 'cos_squared'][:min(4, len(fixed_groups(s)))] + ['sin'] * max(0, len(fixed_groups(s))-4),
                raw_signal_mean=float(raw.mean()), raw_signal_sd=sd,
                target_signal_sd=g['target_signal_sd'], sigma2=g['sigma2'],
                scaling='Center and rescale the full noiseless generated sample to SD=1.5, ddof=0; then add noise.',
                dataset_hash=canonical_hash(spec))
    arrays = dict(X=X, y=y, signal=signal, feature_true=truth,
                  train_idx=idx[:nt], test_idx=idx[nt:],
                  seed=np.asarray(seed), scenario=np.asarray(scenario),
                  dataset_hash=np.asarray(info['dataset_hash']))
    return arrays, info


def dataset_path(root, scenario, seed):
    return Path(root) / 'datasets' / scenario / f'seed_{seed}.npz'


def save_dataset(root, scenario, seed):
    dest = dataset_path(root, scenario, seed)
    expected = canonical_hash(dataset_spec(scenario, seed))
    if dest.exists():
        with np.load(dest, allow_pickle=False) as z:
            if str(z['dataset_hash'].item()) != expected:
                raise RuntimeError(f'Old/incompatible data at {dest}. Use a new root.')
        if not dest.with_suffix('.json').exists():
            raise RuntimeError(f'Missing metadata: {dest.with_suffix(".json")}')
        return dest
    arrays, info = simulate(scenario, seed)
    dest.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(suffix='.npz', dir=dest.parent); os.close(fd)
    try:
        np.savez_compressed(tmp, **arrays)
        write_json(dest.with_suffix('.json'), info)
        os.replace(tmp, dest)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)
    return dest


def load_dataset(path):
    with np.load(path, allow_pickle=False) as z:
        arrays = {k: z[k].copy() for k in z.files}
    arrays['info'] = read_json(Path(path).with_suffix('.json'))
    return arrays
