# Implementation provenance and training-budget decisions

## User-supplied basis

The base experiment archive and its update, v2, v3-r-rich, and v4-R-parser patches
were overlaid in that order for inspection. This folder replaces their experiment
orchestration, simulator and reporting layer, and retains the core DSS MLP API and
the baseline adapter model/prior conventions. It does not contain a copy of the
external R package or DSS model core.

The **latest user specification** takes precedence over every older patch:
MLP only, 2000/200/10 main design, 20 seeds, paired-product trig plus the first two
raw interactions, (20,20) fitted width, DSS 2000/400/3e-4 and cyclic3 repeated twice,
all other learning rates <=1e-4, accuracy instead of AUPRC, 95% CIs, appendix
2000/200/40 and 2000/500/10. CPU/8G/24h/no array throttle are retained from the
settled HPC requirements.

## SS-GL and SS-GHS

Paper: Jantre, Bhattacharya and Maiti, *Spike-and-slab shrinkage priors for
structurally sparse Bayesian neural networks*, arXiv:2308.09104.
https://arxiv.org/html/2308.09104

Appendix A.4 reports 1200 epochs and minibatch 1024 for the paper's MLP
experiments. The present 4000-epoch schedule is the user's previously fixed
conservative budget, not that paper's original duration. The paper's learning
rate is deliberately NOT reused. Both study learning rates are 1e-4.

Official layers reused from the existing HPC checkout:
https://github.com/jsanket12/SS_Group_Shrinkage_New

Files: `Group_Lasso_linear_layers_non_center.py` and
`GHS_linear_layers_non_center_reg.py`. The actual local source hashes, not merely
an assumed upstream branch, are recorded with each submission/run. The wrappers
retain the supplied adapter's regression mean-MSE + KL/N objective and its native
node-level sparsification. Changing minibatch size changes the optimization
trajectory/update count; it does NOT algebraically multiply the KL/N coefficient
relative to the average data loss by the number of batches.

## LBBNN family and IS-ANN-L1

Package source/API:
https://cran.r-project.org/package=LBBNN
https://github.com/cran/LBBNN/blob/master/R/Train_validate.R
https://github.com/cran/LBBNN/blob/master/R/LBBNN_Model.R
https://github.com/cran/LBBNN/blob/master/R/overwrite_functions.R

Method reference:
https://arxiv.org/abs/2503.10496

The runtime is pinned to the user's working LBBNN 0.1.6 / R 4.4.2 stack.
The package exposes `epochs` and `lr` as caller-supplied arguments; its examples
use different budgets for different data. The current 2000-epoch LBBNN and
IS-ANN budgets retain the supplied experiment's budgets. They are study choices,
not a statement that a single 2000-epoch setting is prescribed by every paper.
All four R-based methods receive exactly 1e-4 from the central config. No
paper-native learning rate or previous 5e-4/0.005/0.01 value is used.

The deterministic input-skip ANN is the existing experiment's R-torch adapter,
not an official posterior implementation. Its L1 penalty and cutoff are retained;
the learning rate is now explicitly passed rather than separately hardcoded.
