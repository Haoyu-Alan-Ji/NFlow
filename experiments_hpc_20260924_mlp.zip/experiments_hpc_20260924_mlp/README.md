# MLP-only benchmark: fixed paired-product trigonometric signal

This is a complete experiment folder, not another patch that must be stacked onto
v2/v3/v4. Put it next to `~/NFlow/Python` and the existing
`~/NFlow/experiments_hpc_20260923` folder. The old folder, data, results, R library,
conda environment and external repositories are not overwritten.

## Frozen scope

| Scenario | Role | n | p | Active s | Active fraction | Fits |
|---|---|---:|---:|---:|---:|---:|
| `main` | One main-text table | 2000 | 200 | 10 | 5% | 7 x 20 = 140 |
| `s20` | Appendix | 2000 | 200 | 40 | 20% | 7 x 20 = 140 |
| `s02` | Appendix | 2000 | 500 | 10 | 2% | 7 x 20 = 140 |

There are **420 formal fits** in total. Every fit has two hidden layers of width
20. Native input-skip connections are retained for ISLaB-FLOW and IS-ANN-L1.
Seeds are 400--419. Every scenario uses the same 80/20 split rule: 1600 training
observations and 400 test observations. No test data are used for training,
model selection, early stopping, or learning-rate adjustment.

No shallow experiment, MCMC reference, unit-recovery metric, recovery curve,
architecture ablation, posterior-coverage experiment, or historical five-simulator
screen is executed by this folder. Internal DSS feature/unit states remain part
of the MLP sparsity model; they are not evaluated against teacher-unit identities.

## Exact data-generating mechanism

The active columns are the first `s` columns, in a fixed order. Using one-based
notation, group them as `(1,2), (3,4), (5,6), ...`; an odd last column is a
singleton. For a pair, `u_h = x_(2h-1) * x_(2h)`; for a singleton, its value is
that predictor itself.

The component sequence is fixed:

- group 1: `sin(u_1)`;
- group 2: `cos(u_2)`;
- group 3: `[sin(u_3)]^2`, **not** `sin(2*u_3)`;
- group 4: `[cos(u_4)]^2`, **not** `cos(2*u_4)`;
- groups 5 onward: `sin(u_h)`.

Only groups that exist are used. The raw signal is the sum of these components
plus **two raw products**, `x_1*x_2 + x_3*x_4`, with coefficient 1 each. There is
no random teacher network, linear projection, bias, amplitude, random pairing,
frequency multiplication, or separate interaction standardization. An impossible
interaction count raises an error rather than being silently truncated.

The unchanged background conventions from the supplied simulator are explicit:
independent uniform predictors on `[-2.5, 2.5]`, full generated noiseless-signal
centering/rescaling to standard deviation 1.5 (`ddof=0`), and independent Gaussian
noise of variance 1. The formula above defines the **raw** signal; the final
conditional mean is `(raw - raw_mean) * 1.5 / raw_sd`. Each data JSON stores these
constants. `true_mean(X, info)` uses the stored constants, not mutable config.
This normalization is a simulation convention, not an estimated preprocessing
step performed by a competing fit.

A common 500-column uniform draw is generated per seed and sliced for p=200.
Consequently, `main` and `s02` have exactly the same active inputs, responses,
noise and split; `s02` adds 300 null columns. `s20` changes the number of active
columns while retaining the same design, split and noise realization. The larger
active set also changes the signal components; it is not claimed to alter only
one abstract scalar sparsity parameter.

## Fixed training configuration

| Method | Epochs | Learning rate | Training batch | Final MC draws |
|---|---:|---:|---:|---:|
| DSS-LVR | 2000, including 400 warmup | 0.0003 | full training data | 500 |
| LBBNN-LRT | 2000 | 0.0001 | 128 | 500 |
| LBBNN-FLOW | 2000 | 0.0001 | 128 | 500 |
| ISLaB-FLOW | 2000 | 0.0001 | 128 | 500 |
| SS-GL | 4000 | 0.0001 | 1024 | 100 |
| SS-GHS | 4000 | 0.0001 | 1024 | 100 |
| IS-ANN-L1 | 2000 | 0.0001 | 128 | deterministic |

Here *epochs* are optimization iterations/passes, not MCMC chain lengths. The
DSS schedule has 400 all-on warmup iterations followed by 1600 ordinary ELBO
iterations, not 2400 total iterations. DSS uses 32 training posterior samples,
MADE width 128 and two conditioner hidden layers, gradient-norm clipping at 5,
log-scale clipping at 2, and normalized-ReQU scale 1, as in the supplied adapter.
Its **six flow transformations are the three role orderings repeated twice**:
`U<V<tau`, `V<tau<U`, `tau<U<V`, then the same cycle again. This is not a tau-last
stack. The conditioner depth is distinct from the flow depth.

Every competitor is capped at `lr <= 1e-4`, checked centrally and in its runner.
No paper learning rate is imported, even when an example uses 1e-3 or 1e-2.
`experiment_config.py` is the single source of training settings: both
`train_lbbnn` and the deterministic R ANN explicitly receive `c$lr`. In
particular, the old ANN adapter's separate hardcoded `.01` no longer survives.

SS keeps the previously requested `4000 / 1e-4 / 1024` schedule. Its native paper
MLP budget was 1200 epochs, so 4000 is explicitly a study-specific conservative
budget, **not** a claim of verbatim paper replication. LBBNN/IS-ANN retain the
supplied experiment's 2000-epoch budget. See `SOURCES.md`; no result-dependent
or seed-specific retuning is performed.

Other adapter conventions are retained: LBBNN inclusion prior 0.5, prior SD 1,
polarized inclusion initialization, He weight initialization, two RNVP transforms
and `(50,50)` flow conditioners; ANN L1 coefficient 0.01 and weight cutoff 0.005;
SS official non-centered layers, temperature 0.5, architecture-dependent node
inclusion prior, GL Gamma hyperprior `(4,2)`, and GHS regularization constant 1.
The SS wrapper retains its mean-MSE + KL/N objective. There is no undocumented
reweighting of KL, prior change, softplus patch, competitor gradient clipping,
or checkpoint selection. Finite-value guards diagnose failures; they do not
replace NaN/Inf with valid values.

## Metrics and 95% confidence intervals

The columns are `Method, n_fit, TPR, FPR, Accuracy, AUROC, MSE, R_f^2, D_param,
D_E, D_pi, Time (min)`. **AUPRC is not computed or exported.**

Accuracy means `(TP+TN)/p` for predictor selection, not outcome classification.
MSE and R_f^2 compare the fitted mean with the **noiseless test signal**, not the
noisy response. `Time` is training wall-clock time in minutes; per-run JSON also
retains summary time and total elapsed time for auditing.

Predictor selection uses DSS hard-event PIPs above 0.5; the LBBNN native
active-path rule (at least one retained input-to-output path); or the ANN native
thresholded active-path rule. LBBNN AUROC uses mean incident input-edge PIPs as a
ranking score, and ANN AUROC uses incident absolute weights, as in the supplied
adapters. These ranking scores are not relabelled as exact predictor PIPs.
SS-GL/GHS provide native node selection, not predictor PIPs: their four
predictor-selection cells are `--`, rather than fabricated zeroes or a
truth-informed top-k selection.

All density denominators exclude biases. `D_param` is the fraction of retained
weights in each method's native hard sparse architecture. `D_E` is a posterior
expected edge fraction **only for DSS-LVR**; it is `--` for other methods because
their previous exported density values did not have that posterior meaning.
DSS `D_pi` averages the active-path fraction over joint hard-state posterior
draws. Other `D_pi` entries use native hard graphs, retaining input-skip paths
in the numerator and denominator when those paths exist. These are explicitly
different structural summaries, not identically defined posterior quantities.

For every supported metric, aggregation uses the replicate mean and a two-sided
95% Student-t interval `mean +/- t_(.975,n_fit-1) * SD/sqrt(n_fit)`. Intervals are
intersected with feasible metric ranges: [0,1] for proportions, [0,infinity) for
MSE/time, and (-infinity,1] for R_f^2. This is a seed-level frequentist confidence
interval, **not** a posterior credible interval. One finite replicate gets a
mean but no claimed CI. No replicate is discarded to reduce interval width.

The table shows each mean on its first line and `[lower,upper]` underneath.
Long scientific-notation intervals use an extra line to avoid shrinking the whole table.
The brief footnote reports included/failed/missing counts and the metric caveat;
full model settings are kept here rather than placed under the table.

## Failed and poor fits

One atomic JSON is written per method/scenario/seed. A non-finite loss, parameter,
prediction or required metric records a failure with its stage and error.
Completed fits with finite but very large MSE or negative R_f^2 remain included.
No winsorization, clipping of performance values, removal of poor seeds, or
automatic seed-specific rescue is used. Do not label every failure as a softplus
failure: the JSON records the observed error rather than an unverified cause.
Unsupported metrics remain null and do not turn a fit into a failure.

Aggregation does **not** require every fit to succeed. It displays the true
`n_fit`, excluded failures, and missing/invalid records. A Slurm job killed before
it writes a JSON appears as missing; `check_status.py --slurm` supplies the
scheduler state. A scheduler `COMPLETED` alone is not result validation.

No old 5000/200/10 result, old random-ridge simulator, GPU failure, smoke result,
or alternative learning-rate run is accepted into this study. Config, DGP and
source-code hashes are checked. Formal scripts are frozen to an immutable code
snapshot at submission so later edits do not alter queued tasks. External core
and SS source hashes are verified again by the worker. Use a **new result root**
for any changed scientific or executable configuration.

## Installation: keep the existing packages

From local PowerShell:

```powershell
scp .\experiments_hpc_20260924_mlp.zip ji000232@login.msi.umn.edu:~/NFlow/
ssh ji000232@login.msi.umn.edu
```

On HPC:

```bash
cd ~/NFlow
unzip experiments_hpc_20260924_mlp.zip
cd ~/NFlow/experiments_hpc_20260924_mlp
source hpc/env.sh
python hpc/preflight.py
```

Default reused dependencies:

```text
~/NFlow/Python/model2.py
~/NFlow/experiments_hpc_20260923/external_methods/SS_Group_Shrinkage_New/
~/R/r-rich-4.4.2/
conda: nf311
module: r-rich/4.4.2_msi1.2
```

The package does not install or modify these dependencies. `bnn_mcmc.py` and
`bnn_metric.py` are not imported by this folder. The current DSS core must expose
its existing `GroupedBNNVI` slab initialization, IAF and decoder-semantic APIs.
Preflight verifies that API plus a tiny finite ELBO/backward calculation.

For a different existing dependency location, set `NFLOW_PROJECT_ROOT` and
`NFLOW_SS_REPO`, or write `paths.local.json` in this folder:

```json
{"project_root": "/absolute/path/NFlow", "ss_repo": "/absolute/path/SS_Group_Shrinkage_New"}
```

## Run order

Prepare exactly 60 datasets once (there is no old curve-refresh step):

```bash
python make_datasets.py --scenario all
python tests/test_pipeline.py
python tests/test_submission.py
Rscript tests/test_r_graph.R
```

An optional seven-path smoke test uses the same data dimensions and three
training epochs, in a separate result root. It has **no** publication results:

```bash
python make_datasets.py --scenario main --root results_smoke
python hpc/submit.py --scenario main --smoke
# After those seven jobs terminate:
python check_status.py --scenario main --smoke --root results_smoke --slurm
```

Submit the main experiment once:

```bash
python hpc/submit.py --scenario main --dry-run
python hpc/submit.py --scenario main
```

This submits **7 arrays x 20 tasks**, indices 0--19 corresponding to seeds
400--419. Do not reuse the old indices 10--19/40--49: there is now one simulator,
and scenarios are selected by name. Every task requests **1 CPU, 8G, 24 hours,
partition msismall**, with **no `%` concurrency throttle** and no GPU request.
Resource availability/account rules can still delay task starts.

The appendices use the same runner and fixed hyperparameters:

```bash
python hpc/submit.py --scenario s20
python hpc/submit.py --scenario s02
# Equivalent single command, instead of the two above:
# python hpc/submit.py --scenario appendix
```

`--scenario all` submits all three scenarios in one invocation. Repeated
submission commands skip already active replicates and existing terminal results.
Nothing automatically reruns a numerical failure. To explicitly retry only
failed/missing paths without changing settings, use
`python hpc/submit.py --scenario main --retry-failed`.

Job IDs are appended to `results/submissions.tsv`, including the scenario,
method and exact indices. Do not manually re-submit a second copy of an array.

## Check after restarting the computer

```bash
ssh ji000232@login.msi.umn.edu
cd ~/NFlow/experiments_hpc_20260924_mlp
source hpc/env.sh
squeue -u "$USER" -r -o "%.20i %.24j %.2t %.12M %R"
python check_status.py --scenario main --slurm
# Later, for all three scenarios:
python check_status.py --scenario all --slurm
```

A nonzero status-check exit means at least one requested result is failed,
missing or invalid; it does not delete data or prevent deliberate successful-fit
aggregation. The command reports stages and error messages directly from JSON.

## Produce the tables

The main table can be produced before the appendices finish:

```bash
python aggregate_results.py --scenario main
```

When all three scenarios have been attempted:

```bash
python aggregate_results.py --scenario all
```

Main outputs:

```text
results/final/main_table.tex           one main-text MLP table
results/final/appendix_s20.tex         appendix: 40/200 active
results/final/appendix_s02.tex         appendix: 10/500 active
results/final/appendix_tables.tex      the two appendix tables together
results/final/summary_95ci.csv         all means, CI endpoints and metric-specific n
results/final/completion_audit.csv     included/failed/missing/invalid counts
results/final/runs_used_and_excluded.csv   seed-level audit and input metrics
results/final/tables_preview.tex       optional standalone compilation wrapper
```

Use `booktabs`, `graphicx`, and `amsmath` in the manuscript. Insert
`\input{main_table.tex}` in the main text and the two appendix tables in the
appendix. The compact wording in `manuscript/experiment_design.tex` describes
only this experiment and does not promise unperformed MCMC/ablation results.

To transfer the small final outputs after aggregation:

```bash
tar -czf mlp_tables_95ci.tar.gz -C results final
```

From local PowerShell:

```powershell
scp ji000232@login.msi.umn.edu:~/NFlow/experiments_hpc_20260924_mlp/mlp_tables_95ci.tar.gz .
```

## Validation scope

The included unit tests cover exact trig squaring, fixed pairs, singleton groups,
interaction-count errors, controlled p-extension, dimensions/splits, deterministic
data, frozen scaling, learning-rate caps, selection accuracy, t intervals,
unsupported metrics, failure exclusion without finite-outlier exclusion, and
LaTeX output. They do not certify numerical convergence of 420 unrun fits.
`hpc/preflight.py` performs the actual R parser/library/tensor checks on MSI;
`tests/test_r_graph.R` checks graph counting under R. A seven-method smoke suite
checks the installed backends end-to-end before long jobs. No full HPC training
has been executed while preparing this folder.
