"""DSS-LVR MLP VI only. Does not import a sampler or any shallow runner."""
from __future__ import annotations
import inspect
import random
import time
import numpy as np
import torch
from paths import import_dss_model
from metrics_common import function_metrics, selection_metrics


def require_finite(t, name):
    if not bool(torch.isfinite(t).all()):
        raise FloatingPointError(f'{name} contains NaN/Inf')


def build_model(X, y, c, fit_seed):
    md = import_dss_model()
    kwargs = dict(X=X, y=y, input_dim=X.shape[1], hidden_dims=tuple(c['hidden_dims']), out_dim=1,
        selection_mode='feature_unit_induced_edge', family='gaussian', sigma2=c['sigma2'],
        init_sd=c['init_sd'], K_flow=c['flow_layers'], flow_type='iaf',
        flow_hidden_units=c['flow_hidden_units'], flow_hidden_layers=c['flow_hidden_layers'],
        scale_clip=c['scale_clip'], flow_seed=fit_seed+17, iaf_ordering_scheme=c['ordering'],
        iaf_shuffle_within_role=True, gate_type=c['gate'], gate_scale=c['gate_scale'])
    params = inspect.signature(md.GroupedBNNVI.__init__).parameters
    if 'slab_init' not in params:
        raise RuntimeError('The core model2.py lacks the validated slab initialization API. Use the current NFlow core.')
    kwargs.update(slab_init=c['slab_init'], slab_sd_ratio=c['slab_sd_ratio'], slab_bias_sd=c['slab_bias_sd'])
    model = md.GroupedBNNVI(**kwargs).to('cpu')
    gen = torch.Generator(device='cpu').manual_seed(fit_seed+99173)
    with torch.no_grad():
        model.q0.loc.add_(c['init_loc_jitter'] * torch.randn(model.q0.loc.shape, generator=gen, dtype=model.q0.loc.dtype))
    return model


def run(data, c, fit_seed, stage):
    random.seed(fit_seed); np.random.seed(fit_seed); torch.manual_seed(fit_seed)
    tr, te = data['train_idx'], data['test_idx']
    X = torch.as_tensor(data['X'], dtype=torch.float32)
    y = torch.as_tensor(data['y'], dtype=torch.float32)
    stage('build_model')
    model = build_model(X[tr], y[tr], c, fit_seed)
    opt = torch.optim.Adam(model.parameters(), lr=c['lr'])
    stage('training')
    t0 = time.perf_counter()
    for ep in range(1, c['epochs']+1):
        model.train(); opt.zero_grad(set_to_none=True)
        if ep <= c['warmup']:
            xi, logq = model.sample_posterior(c['r_train'])
            elbo = model.log_likelihood(xi, force_all_on=True) + model.log_prior(xi) - logq
        else:
            elbo = model.elbo_draws(c['r_train'])['elbo']
        loss = -elbo.mean()
        require_finite(loss, f'DSS loss at epoch {ep}')
        loss.backward()
        norm = torch.nn.utils.clip_grad_norm_(model.parameters(), c['grad_clip'], error_if_nonfinite=True)
        opt.step()
    train_sec = time.perf_counter()-t0
    stage('posterior_summary')
    t1 = time.perf_counter(); model.eval()
    with torch.no_grad():
        xi, _ = model.sample_posterior(c['draws'])
        require_finite(xi, 'DSS posterior draws')
        feature = model.decoder.feature_semantics(xi)['active'].bool()
        units = model.decoder.unit_semantics(xi)['active'].bool()
        h1, h2 = c['hidden_dims']
        if units.shape[1] != h1+h2 or feature.shape[1] != X.shape[1]:
            raise ValueError('Unexpected DSS feature/unit layout')
        # Joint hard-event draws, NOT a product of marginal PIPs.
        nf = feature.sum(1).double(); n1 = units[:, :h1].sum(1).double(); n2 = units[:, h1:].sum(1).double()
        denom = X.shape[1]*h1 + h1*h2 + h2
        edge = float(((nf*n1+n1*n2+n2)/denom).mean())
        path = float((nf*n1*n2/(X.shape[1]*h1*h2)).mean())
        fp = feature.float().mean(0).numpy(); up = units.float().mean(0).numpy()
        sf = int((fp > c['threshold']).sum())
        a1 = int((up[:h1] > c['threshold']).sum()); a2 = int((up[h1:] > c['threshold']).sum())
        dparam = (sf*a1 + a1*a2 + a2)/denom
        predictions = []
        for start in range(0, len(te), 128):
            pred = model.decoder(X[te[start:start+128]], xi).mean(0).reshape(-1)
            require_finite(pred, 'DSS predictions'); predictions.append(pred.numpy())
    post_sec = time.perf_counter()-t1
    out = function_metrics(data['signal'][te], np.concatenate(predictions))
    out.update(selection_metrics(fp, data['feature_true'], threshold=c['threshold']))
    out.update(dparam=dparam, d_edge=edge, d_path=path, time_min=train_sec/60,
               training_sec=train_sec, summary_sec=post_sec, epochs_completed=c['epochs'],
               feature_scores=fp.tolist(), n_retained_hidden=[a1, a2],
               parameter_count=sum(v.numel() for v in model.parameters()),
               prediction_rule='posterior-mean prediction from the existing exact-zero decoder',
               density_rule='hard group-MPM dparam; joint posterior expected edge/path densities; weights only')
    return out
