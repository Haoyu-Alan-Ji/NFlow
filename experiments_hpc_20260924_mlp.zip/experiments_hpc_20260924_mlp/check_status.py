#!/usr/bin/env python3
import argparse
import csv
from pathlib import Path
import subprocess
import experiment_config as cfg
from io_common import HERE
from result_reader import read_one


def slurm(root):
    ledger = Path(root)/'submissions.tsv'
    if not ledger.exists():
        print('No submission ledger at',ledger); return
    with ledger.open() as f: entries=list(csv.DictReader(f,delimiter='\t'))
    ids = sorted(set(v['job_id'] for v in entries))
    if not ids: return
    cmd = ['sacct','-X','-j',','.join(ids),'--starttime=2026-09-01','--format=JobID%24,JobName%24,State%20,Elapsed,ExitCode']
    print(' '.join(cmd),flush=True)
    subprocess.run(cmd,check=True)
    print('Scheduler attempts are historical; current JSON counts below use one result per method/scenario/seed.')


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--scenario',choices=['all',*cfg.SCENARIOS],default='main')
    p.add_argument('--root',type=Path,default=HERE/'results')
    p.add_argument('--smoke',action='store_true')
    p.add_argument('--slurm',action='store_true')
    a=p.parse_args()
    if a.slurm: slurm(a.root)
    scenarios=list(cfg.SCENARIOS) if a.scenario=='all' else [a.scenario]
    seeds=cfg.SEEDS[:1] if a.smoke else cfg.SEEDS
    bad=False
    print('scenario  method        ok  failed  missing  invalid')
    for scenario in scenarios:
        for method in cfg.METHODS:
            rows=[read_one(a.root,scenario,method,seed,a.smoke) for seed in seeds]
            counts={s:sum(v['status']==s for v in rows) for s in ('ok','failed','missing','invalid')}
            print(f'{scenario:8}  {method:12}  '+ '  '.join(f'{counts[s]:5}' for s in counts))
            for v in rows:
                if v['status'] not in ('ok',):
                    bad=True
                    print(f'  seed={v["data_seed"]} status={v["status"]} stage={v.get("stage", "--")}: {v.get("error_message", "")[:250]}')
    if not bad: print('All requested results passed finite-metric validation.')
    elif not a.smoke: print('Aggregation may still report completed finite fits, with explicit failure/missing counts.')
    raise SystemExit(2 if bad else 0)

if __name__=='__main__': main()
