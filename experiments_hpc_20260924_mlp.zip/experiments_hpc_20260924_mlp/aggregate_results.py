#!/usr/bin/env python3
"""Means and 95% seed-level CIs, with transparent failed/missing counts."""
from __future__ import annotations
import argparse
import csv
from pathlib import Path
import numpy as np
import pandas as pd
import experiment_config as cfg
from io_common import HERE, ensure_design
from metrics_common import mean_ci, metric_bounds
from result_reader import read_one


def fmt(x, metric):
    if x is None or not np.isfinite(x): return '--'
    if x != 0 and (abs(x) >= 1e4 or abs(x) < 5e-5):
        e = int(np.floor(np.log10(abs(x))))
        return rf'{x/10**e:.2f}\!\times\!10^{{{e}}}'
    digits = 1 if metric=='time_min' else (4 if metric in ('dparam','d_edge','d_path') else 3)
    return f'{x:.{digits}f}'


def cell(row, key):
    if row.get(key) is None or not np.isfinite(row[key]): return '--'
    m, lo, hi = (fmt(row.get(key+suffix),key) for suffix in ('','_lo','_hi'))
    if lo=='--': return rf'\shortstack[r]{{${m}$\\{{\tiny CI unavailable}}}}'
    if 'times' in lo or 'times' in hi:
        # Long scientific-notation bounds use two CI lines, not a tiny entire table.
        return rf'\shortstack[r]{{${m}$\\{{\tiny $[{lo},$}}\\{{\tiny ${hi}]$}}}}'
    return rf'\shortstack[r]{{${m}$\\{{\tiny $[{lo},{hi}]$}}}}'


def tex_table(rows, scenario, counts):
    dims = cfg.SCENARIOS[scenario]
    label = 'main' if scenario=='main' else scenario
    caption = (rf'MLP recovery and sparsity under the paired-product trigonometric-interaction simulator '
               rf'($n={dims["n"]}$, $p={dims["p"]}$, $s={dims["s"]}$). Entries are means with 95\% confidence intervals.')
    lines = [r'\begin{table*}[t]',r'\centering',r'\caption{'+caption+'}',
             r'\label{tab:mlp-'+label+'}',r'\scriptsize',r'\setlength{\tabcolsep}{3pt}',
             r'\renewcommand{\arraystretch}{1.3}',r'\resizebox{\textwidth}{!}{%',
             r'\begin{tabular}{@{}lrrrrrrrrrrr@{}}',r'\toprule',
             r'Method & $n_{\rm fit}$ & TPR & FPR & Accuracy & AUROC & MSE & $R_f^2$ & $D_{\rm param}$ & $D_E$ & $D_\pi$ & Time (min) \\',r'\midrule']
    for row in rows:
        vals = [row['method'],str(row['n_fit'])]+[cell(row,k) for k in cfg.METRICS]
        lines.append(' & '.join(vals)+r' \\')
    excluded = sum(c['n_failed'] for c in counts)
    missing = sum(c['n_missing'] for c in counts)
    invalid = sum(c['n_invalid'] for c in counts)
    completed = sum(c['n_fit'] for c in counts)
    failure_detail = ', '.join(f'{c["method"]}: {c["n_failed"]}' for c in counts if c['n_failed'])
    note = (f'Each method has 20 planned replicates; {completed}/140 finite completed fits are included. '
            + (f'Numerical/execution failures excluded ({failure_detail}). ' if excluded else 'No recorded execution failures. ')
            + (f'{missing} replicates have not produced a terminal result. ' if missing else '')
            + (f'{invalid} incompatible/invalid records excluded; see audit. ' if invalid else '')
            + r'Finite poor fits are retained. Intervals are seed-level Student-$t$ confidence intervals, intersected with feasible metric bounds. '
            + r'$D_E$ is DSS-LVR posterior-expected edge density; $D_\pi$ is posterior-expected for DSS-LVR and native hard-path density otherwise. '
            + r'-- denotes an unsupported metric; accuracy is predictor-selection accuracy.')
    lines += [r'\bottomrule',r'\end{tabular}}',r'\vspace{2pt}',r'\begin{minipage}{\textwidth}',
              r'\footnotesize\textit{Note.} '+note,r'\end{minipage}',r'\end{table*}']
    return '\n'.join(lines)+'\n'


def aggregate(root, scenarios):
    ensure_design(root)
    outdir = Path(root)/'final'; outdir.mkdir(parents=True,exist_ok=True)
    summary = []; audit = []; allrows = []; appendices = []
    for scenario in scenarios:
        rows_this = []; counts_this = []
        for method in cfg.METHODS:
            rows = [read_one(root,scenario,method,s) for s in cfg.SEEDS]
            allrows.extend(rows)
            ok = [v for v in rows if v['status']=='ok']
            count = dict(scenario=scenario,method=method,n_planned=len(cfg.SEEDS),n_fit=len(ok),
                         n_failed=sum(v['status']=='failed' for v in rows),
                         n_missing=sum(v['status']=='missing' for v in rows),
                         n_invalid=sum(v['status']=='invalid' for v in rows),
                         failed_seeds=';'.join(str(v['data_seed']) for v in rows if v['status']=='failed'))
            counts_this.append(count); audit.append(count)
            r = dict(count)
            for key in cfg.METRICS:
                supported = not (method in ('SS-GL','SS-GHS') and key in ('tpr','fpr','accuracy','auroc'))
                supported &= not (method!='DSS-LVR' and key=='d_edge')
                if ok and supported:
                    vals = [v[key] for v in ok]
                    m,lo,hi = mean_ci(vals,cfg.CI_LEVEL,metric_bounds(key))
                    r[key+'_n'] = len(vals)
                else:
                    m=lo=hi=None; r[key+'_n']=0
                r[key]=m; r[key+'_lo']=lo; r[key+'_hi']=hi
            summary.append(r); rows_this.append(r)
        table = tex_table(rows_this,scenario,counts_this)
        (outdir/('main_table.tex' if scenario=='main' else f'appendix_{scenario}.tex')).write_text(table,encoding='utf-8')
        if scenario!='main': appendices.append(table)
        print(f'{scenario}: included={sum(c["n_fit"] for c in counts_this)}/140 failed={sum(c["n_failed"] for c in counts_this)} missing={sum(c["n_missing"] for c in counts_this)} invalid={sum(c["n_invalid"] for c in counts_this)}')
    pd.DataFrame(summary).to_csv(outdir/'summary_95ci.csv',index=False)
    pd.DataFrame(audit).to_csv(outdir/'completion_audit.csv',index=False)
    keep = ['scenario','method','data_seed','status','stage','error_type','error_message','job_id','array_task_id','design_hash','code_hash','config_hash',*cfg.METRICS]
    pd.DataFrame([{k:v.get(k) for k in keep} for v in allrows]).to_csv(outdir/'runs_used_and_excluded.csv',index=False)
    if appendices:
        (outdir/'appendix_tables.tex').write_text('\n'.join(appendices),encoding='utf-8')
    # A stand-alone LaTeX preview uses only generated tables; no fictitious data.
    inputs = ['main_table.tex' if s=='main' else f'appendix_{s}.tex' for s in scenarios]
    preview = '\n'.join([r'\documentclass[10pt]{article}',r'\usepackage[margin=0.65in]{geometry}',
        r'\usepackage{booktabs,graphicx,amsmath}',r'\begin{document}',
        *[r'\input{'+name+r'}\clearpage' for name in inputs],r'\end{document}'])
    (outdir/'tables_preview.tex').write_text(preview+'\n',encoding='utf-8')
    return summary,audit


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--scenario',choices=['all',*cfg.SCENARIOS],default='main')
    p.add_argument('--root',type=Path,default=HERE/'results')
    a = p.parse_args()
    scenarios = list(cfg.SCENARIOS) if a.scenario=='all' else [a.scenario]
    aggregate(a.root,scenarios)

if __name__=='__main__': main()
