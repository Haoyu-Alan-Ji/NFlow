from __future__ import annotations
import subprocess
from pathlib import Path
import numpy as np
from io_common import HERE, write_json, read_json
from metrics_common import function_metrics, selection_metrics


class RRunError(RuntimeError):
    def __init__(self, message, details):
        super().__init__(message)
        self.details = details


def run(data, c, fit_seed, method, stage, workdir):
    if not 0 < c['lr'] <= 1e-4:
        raise ValueError('R learning rate exceeds the study cap')
    wd = Path(workdir); tr = data['train_idx']; te = data['test_idx']
    for name, value in [('X_train',data['X'][tr]),('y_train',data['y'][tr]),('X_test',data['X'][te])]:
        np.savetxt(wd / (name + '.csv'), value, delimiter=',')
    write_json(wd/'config.json', c)
    output = wd/'r_result.json'
    cmd = ['Rscript',str(HERE/'run_r_single.R'),'--method',method,'--config',str(wd/'config.json'),
           '--seed',str(fit_seed),'--data-dir',str(wd),'--out',str(output),'--graph-script',str(HERE/'r_graph.R')]
    stage('R_backend')
    proc = subprocess.run(cmd, text=True, capture_output=True, cwd=HERE)
    if proc.stdout: print(proc.stdout, end='', flush=True)
    if proc.stderr: print(proc.stderr, end='', flush=True)
    q = read_json(output) if output.exists() else {}
    if proc.returncode or q.get('status') != 'ok':
        details = dict(stage=q.get('stage','R_startup'), error_type=q.get('error_type','RSubprocessError'),
            error_message=q.get('error_message',f'R exited with code {proc.returncode}'),
            stderr_tail=proc.stderr[-8000:], stdout_tail=proc.stdout[-4000:], returncode=proc.returncode)
        raise RRunError(details['error_message'], details)
    stage('metrics')
    out = function_metrics(data['signal'][te], q.pop('y_pred_test'))
    scores = q.pop('scores'); selected = q.pop('selected')
    out.update(selection_metrics(scores, data['feature_true'], selected=selected))
    out.update(q); out['d_edge'] = None; out['feature_scores'] = scores
    return out
