# Pure-R, weights-only input-output graph accounting; matrices are out-by-in.
graph_stats <- function(w1, w2, wo, p, h1, h2, input_skip) {
  stopifnot(identical(dim(w1), c(h1,p)))
  if (input_skip) {
    stopifnot(identical(dim(w2), c(h2,h1+p)), identical(dim(wo), c(1L,h2+p)))
    w2h <- w2[,seq_len(h1),drop=FALSE]
    w2x <- w2[,h1+seq_len(p),drop=FALSE]
    w3h <- wo[,seq_len(h2),drop=FALSE]
    w3x <- wo[,h2+seq_len(p),drop=FALSE]
  } else {
    stopifnot(identical(dim(w2), c(h2,h1)), identical(dim(wo), c(1L,h2)))
    w2h <- w2; w3h <- wo
    w2x <- matrix(FALSE,h2,p); w3x <- matrix(FALSE,1L,p)
  }
  reach1 <- rowSums(w1) > 0
  out2 <- as.logical(w3h[1,])
  out1 <- if (any(out2)) colSums(w2h[out2,,drop=FALSE]) > 0 else rep(FALSE,h1)
  reach2 <- (if (any(reach1)) rowSums(w2h[,reach1,drop=FALSE]) > 0 else rep(FALSE,h2)) | rowSums(w2x)>0
  a1 <- w1 & matrix(out1,h1,p)
  a2h <- w2h & outer(out2,reach1,'&')
  a2x <- w2x & matrix(out2,h2,p)
  a3h <- w3h & matrix(reach2,1L,h2)
  a3x <- w3x
  paths <- sum((a3h*1) %*% (a2h*1) %*% (a1*1)) + sum((a3h*1) %*% (a2x*1)) + sum(a3x)
  denom_path <- p*h1*h2 + (if (input_skip) p*h2+p else 0)
  candidate <- length(w1)+length(w2)+length(wo)
  retained <- sum(a1)+sum(a2h)+sum(a2x)+sum(a3h)+sum(a3x)
  list(selected=colSums(a1)>0 | colSums(a2x)>0 | as.logical(a3x[1,]),
       dparam=retained/candidate, d_path=paths/denom_path,
       a1=a1, a2=if(input_skip) cbind(a2h,a2x) else a2h,
       a3=if(input_skip) cbind(a3h,a3x) else a3h)
}
