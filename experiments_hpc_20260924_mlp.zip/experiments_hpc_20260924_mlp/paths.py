"""Reuse existing installations without deleting or copying them."""
from __future__ import annotations
import os
import sys
from pathlib import Path
from io_common import HERE, read_json, file_hash


def resolve_paths():
    local = HERE / 'paths.local.json'
    saved = read_json(local) if local.exists() else {}
    project = Path(os.environ.get('NFLOW_PROJECT_ROOT', saved.get('project_root', str(HERE.parent)))).expanduser().resolve()
    repo = Path(os.environ.get('NFLOW_SS_REPO', saved.get('ss_repo', str(project / 'experiments_hpc_20260923' / 'external_methods' / 'SS_Group_Shrinkage_New')))).expanduser().resolve()
    return project, repo


def dependencies(method=None):
    project, repo = resolve_paths()
    req = {}
    if method in (None, 'DSS-LVR'):
        req['DSS_model2'] = project / 'Python' / 'model2.py'
    if method in (None, 'SS-GL', 'SS-GHS'):
        if method in (None, 'SS-GL'):
            req['SS_GL_layer'] = repo / 'Group_Lasso_linear_layers_non_center.py'
        if method in (None, 'SS-GHS'):
            req['SS_GHS_layer'] = repo / 'GHS_linear_layers_non_center_reg.py'
    for name, path in req.items():
        if not path.is_file():
            raise FileNotFoundError(f'{name}: {path}. See README paths; no package reinstall is required.')
    return {name: {'path': str(path), 'sha256': file_hash(path)} for name, path in req.items()}


def import_dss_model():
    project, _ = resolve_paths()
    dependencies('DSS-LVR')
    sys.path.insert(0, str(project))
    from Python import model2
    return model2
