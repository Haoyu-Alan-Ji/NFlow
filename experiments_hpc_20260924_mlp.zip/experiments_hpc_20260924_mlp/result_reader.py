from pathlib import Path
import experiment_config as cfg
from io_common import canonical_hash, read_json, result_path
from run_task import check_required


def read_one(root, scenario, method, seed, smoke=False):
    path = result_path(root,scenario,method,seed)
    dims = cfg.SCENARIOS[scenario]
    base = dict(scenario=scenario,method=method,data_seed=seed,n=dims['n'],p=dims['p'],s=dims['s'])
    if not path.exists(): return dict(base,status='missing',error_message='No terminal result JSON')
    try:
        row = read_json(path)
        config = cfg.training_config(method,smoke); config['sigma2'] = cfg.DGP['sigma2']
        if any(row.get(k)!=v for k,v in base.items()): raise ValueError('Result identity mismatch')
        if row.get('config_hash') != canonical_hash(config) or row.get('design_hash') != canonical_hash(cfg.design()):
            raise ValueError('Result training/DGP config mismatch')
        if bool(row.get('smoke')) != smoke: raise ValueError('Smoke/formal result mismatch')
        execution = Path(root)/'execution.json'
        if execution.exists() and row.get('code_hash') != read_json(execution)['code_hash']:
            raise ValueError('Result source-code snapshot mismatch')
        if row.get('status') not in ('ok','failed'): raise ValueError('Invalid status')
        if row['status']=='ok': check_required(row,method)
        return row
    except Exception as e:
        return dict(base,status='invalid',error_message=str(e),source=str(path))
