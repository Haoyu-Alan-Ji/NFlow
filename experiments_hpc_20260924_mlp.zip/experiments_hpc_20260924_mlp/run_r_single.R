#!/usr/bin/env Rscript
args <- commandArgs(trailingOnly=TRUE)
getarg <- function(key, default=NULL) {
  i <- match(paste0('--',key), args)
  if (is.na(i)) return(default)
  if (i == length(args)) stop(paste('Missing value for',key))
  args[[i+1L]]
}
stage <- 'load_packages'
out_file <- getarg('out')
set_stage <- function(x) { stage <<- x; cat('STAGE=',x,'\n',sep=''); flush.console() }

main <- function() {
  suppressPackageStartupMessages({library(torch);library(LBBNN);library(jsonlite)})
  if (as.character(packageVersion('LBBNN')) != '0.1.6') stop('This adapter is pinned to LBBNN 0.1.6')
  if (getRversion() != '4.4.2') stop('Load r-rich/4.4.2_msi1.2')
  source(getarg('graph-script'), local=TRUE)
  c <- jsonlite::read_json(getarg('config'),simplifyVector=TRUE)
  method <- getarg('method')
  allowed <- c('LBBNN-LRT','LBBNN-FLOW','ISLaB-FLOW','IS-ANN-L1')
  if (!(method %in% allowed)) stop('Unknown R method')
  if (is.null(c$lr) || !is.finite(c$lr) || c$lr<=0 || c$lr>1e-4) stop('R learning rate must be in (0, 1e-4]')
  epochs <- as.integer(c$epochs); draws <- as.integer(c$draws); batch <- as.integer(c$batch)
  seed <- as.integer(getarg('seed')); set.seed(seed); torch_manual_seed(seed)
  p1 <- function(path) as.numeric(read.csv(path,header=FALSE)[[1]])
  pm <- function(path) as.matrix(read.csv(path,header=FALSE))
  d <- normalizePath(getarg('data-dir'),mustWork=TRUE)
  Xtr <- pm(file.path(d,'X_train.csv')); ytr <- p1(file.path(d,'y_train.csv'))
  Xte <- pm(file.path(d,'X_test.csv'))
  p <- as.integer(ncol(Xtr)); h1 <- as.integer(c$hidden_dims[1]); h2 <- as.integer(c$hidden_dims[2])
  stopifnot(h1==20L,h2==20L,epochs>0,draws>0,batch>0)
  train_dl <- dataloader(tensor_dataset(torch_tensor(Xtr,dtype=torch_float()),torch_tensor(ytr,dtype=torch_float())),
                         batch_size=min(batch,nrow(Xtr)),shuffle=TRUE,num_workers=0)
  test_dl <- dataloader(tensor_dataset(torch_tensor(Xte,dtype=torch_float()),torch_zeros(nrow(Xte))),
                        batch_size=nrow(Xte),shuffle=FALSE,num_workers=0)
  tensor_array <- function(x) as.array(x$detach()$cpu())
  matrix_array <- function(x,nr,nc) {
    a <- tensor_array(x)
    if (!identical(as.integer(dim(a)),c(as.integer(nr),as.integer(nc)))) stop('Unexpected weight matrix shape')
    if (any(!is.finite(a))) stop('Non-finite weight or inclusion matrix')
    a
  }
  assert_parameters <- function(model) {
    for (nm in names(model$parameters)) {
      if (!isTRUE(torch_isfinite(model$parameters[[nm]])$all()$item())) stop(paste('Non-finite parameter:',nm))
    }
  }
  set_stage('build_model')
  cat(sprintf('CONFIG method=%s epochs=%d lr=%.8g batch=%d draws=%d seed=%d\n',method,epochs,c$lr,batch,draws,seed))
  if (method != 'IS-ANN-L1') {
    skip <- isTRUE(c$input_skip)
    model <- lbbnn_net(problem_type='regression',sizes=c(p,h1,h2,1L),
      prior=rep(c$prior,3),std=rep(c$std,3),inclusion_inits=c$inclusion_inits,
      input_skip=skip,flow=isTRUE(c$flow),num_transforms=as.integer(c$num_transforms),
      dims=as.integer(c$flow_dims),device='cpu',bias_inclusion_prob=FALSE,weight_init=c$weight_init)
    set_stage('training'); t0 <- proc.time()[[3]]
    # Original optimizer/objective; only the centrally supplied learning rate is used.
    history <- suppressMessages(train_lbbnn(epochs=epochs,LBBNN=model,lr=c$lr,
      train_dl=train_dl,device='cpu',scheduler=NULL,min_density=NULL,verbose=FALSE))
    train_sec <- proc.time()[[3]]-t0
    if (length(history$loss)!=epochs || any(!is.finite(history$loss))) stop('Incomplete training or non-finite training loss')
    rm(history); assert_parameters(model)
    set_stage('prediction_and_graph'); t1 <- proc.time()[[3]]
    # train_lbbnn has already computed active paths at its final step.
    w1 <- matrix_array(model$layers$children[[1]]$alpha_active_path,h1,p)>0
    w2 <- matrix_array(model$layers$children[[2]]$alpha_active_path,h2,h1+(if(skip) p else 0L))>0
    wo <- matrix_array(model$out_layer$alpha_active_path,1L,h2+(if(skip) p else 0L))>0
    ps <- graph_stats(w1,w2,wo,p,h1,h2,skip)
    a <- tensor_array(predict(model,newdata=test_dl,mpm=TRUE,draws=draws,device='cpu'))
    if (!identical(as.integer(dim(a)),c(draws,as.integer(nrow(Xte)),1L)) || any(!is.finite(a))) stop('Invalid/non-finite MPM prediction draws')
    pred <- vapply(seq_len(nrow(Xte)),function(j) mean(a[,j,1]),numeric(1))
    scores <- matrix_array(torch_sigmoid(model$layers$children[[1]]$lambda_l),h1,p)
    if (skip) {
      a2 <- matrix_array(torch_sigmoid(model$layers$children[[2]]$lambda_l),h2,h1+p)
      a3 <- matrix_array(torch_sigmoid(model$out_layer$lambda_l),1L,h2+p)
      scores <- rbind(scores,a2[,h1+seq_len(p),drop=FALSE],a3[,h2+seq_len(p),drop=FALSE])
    }
    scores <- colMeans(scores)
    summary_sec <- proc.time()[[3]]-t1
  } else {
    ISANN <- nn_module('ISANN',
      initialize=function(p,h1,h2) {
        self$f1 <- nn_linear(p,h1); self$f2 <- nn_linear(h1+p,h2); self$out <- nn_linear(h2+p,1)
      },
      forward=function(x) {
        h <- nnf_relu(self$f1(x))
        h2 <- nnf_relu(self$f2(torch_cat(list(h,x),dim=2)))
        self$out(torch_cat(list(h2,x),dim=2))$squeeze(2)
      })
    model <- ISANN(p,h1,h2)$to(device='cpu')
    opt <- optim_adam(model$parameters,lr=c$lr)
    set_stage('training'); t0 <- proc.time()[[3]]
    for (ep in seq_len(epochs)) {
      model$train()
      coro::loop(for(b in train_dl) {
        opt$zero_grad(); pred <- model(b[[1]])$view_as(b[[2]])
        penalty <- model$f1$weight$abs()$sum()+model$f2$weight$abs()$sum()+model$out$weight$abs()$sum()
        loss <- nnf_mse_loss(pred,b[[2]])+c$l1*penalty
        if (!isTRUE(torch_isfinite(loss)$all()$item())) stop(sprintf('Non-finite ANN loss at epoch %d',ep))
        loss$backward(); opt$step()
      })
    }
    train_sec <- proc.time()[[3]]-t0; assert_parameters(model)
    set_stage('prediction_and_graph'); t1 <- proc.time()[[3]]
    r1 <- abs(matrix_array(model$f1$weight,h1,p)); r2 <- abs(matrix_array(model$f2$weight,h2,h1+p)); r3 <- abs(matrix_array(model$out$weight,1L,h2+p))
    scores <- colSums(r1)+colSums(r2[,h1+seq_len(p),drop=FALSE])+as.numeric(r3[1,h2+seq_len(p)])
    ps <- graph_stats(r1>=c$weight_cutoff,r2>=c$weight_cutoff,r3>=c$weight_cutoff,p,h1,h2,TRUE)
    with_no_grad({
      model$f1$weight$mul_(torch_tensor(ps$a1*1,dtype=torch_float()))
      model$f2$weight$mul_(torch_tensor(ps$a2*1,dtype=torch_float()))
      model$out$weight$mul_(torch_tensor(ps$a3*1,dtype=torch_float()))
    })
    model$eval(); pred <- numeric(0)
    with_no_grad({coro::loop(for(b in test_dl) {pred <- c(pred,as.numeric(tensor_array(model(b[[1]]))))})})
    summary_sec <- proc.time()[[3]]-t1
  }
  if (length(pred)!=nrow(Xte) || any(!is.finite(pred)) || any(!is.finite(scores))) stop('Non-finite predictions or feature scores')
  set_stage('done')
  list(status='ok',stage=stage,y_pred_test=as.numeric(pred),scores=as.numeric(scores),
       selected=as.logical(ps$selected),dparam=unname(ps$dparam),d_edge=NULL,d_path=unname(ps$d_path),
       time_min=train_sec/60,training_sec=train_sec,summary_sec=summary_sec,epochs_completed=epochs,
       r_version=as.character(getRversion()),r_torch_version=as.character(packageVersion('torch')),
       lbbnn_version=as.character(packageVersion('LBBNN')),lr=c$lr,
       prediction_rule=if(method=='IS-ANN-L1') 'pruned deterministic input-skip ANN' else 'native active-path MPM prediction',
       density_rule='native active-path-pruned weights and native input-output paths; excludes biases')
}

answer <- tryCatch(main(),error=function(e) {
  msg <- conditionMessage(e)
  cat('FAILED_STAGE=',stage,'\n',msg,'\n',file=stderr(),sep='')
  list(status='failed',stage=stage,error_type=class(e)[1],error_message=msg)
})
if (!is.null(out_file) && requireNamespace('jsonlite',quietly=TRUE)) {
  jsonlite::write_json(answer,out_file,auto_unbox=TRUE,digits=16,na='null',null='null',pretty=TRUE)
}
if (!identical(answer$status,'ok')) quit(status=2L,save='no')
